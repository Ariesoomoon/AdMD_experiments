import numpy as np
import math
from AdMD_algorithms.Theorem2_wstar import main_function, generate_data
import random
import time
time_start = time.time()

algorithm_nums = 9
T = 100100
# T = 8000
trials = 20
L2norm_ADMD_diff_w_trials = np.empty(shape=(trials, T))
KL_ADMD_diff_w_trials = np.empty(shape=(trials, T))
epsilon_ADMD_diff_w_trials = np.empty(shape=(trials, T))

L2norm_MD_diff_w_trials = np.empty(shape=(trials, T))
KL_MD_diff_w_trials = np.empty(shape=(trials, T))
epsilon_MD_diff_w_trials = np.empty(shape=(trials, T))

SGD_diff_w_trials = np.empty(shape=(trials, T))
AdaGrad_diff_w_trials = np.empty(shape=(trials, T))
Vanilla_diff_w_trials = np.empty(shape=(trials, T))


L2norm_ADMD_error_trials = np.empty(shape=(trials, T))
KL_ADMD_error_trials = np.empty(shape=(trials, T))
epsilon_ADMD_error_trials = np.empty(shape=(trials, T))

L2norm_MD_error_trials = np.empty(shape=(trials, T))
KL_MD_error_trials = np.empty(shape=(trials, T))
epsilon_MD_error_trials = np.empty(shape=(trials, T))

SGD_error_trials = np.empty(shape=(trials, T))
AdaGrad_error_trials = np.empty(shape=(trials, T))
Vanilla_error_trials = np.empty(shape=(trials, T))


L2norm_ADMD_sparse_trials = np.empty(shape=(trials, T))
KL_ADMD_sparse_trials = np.empty(shape=(trials, T))
epsilon_ADMD_sparse_trials = np.empty(shape=(trials, T))

L2norm_MD_sparse_trials = np.empty(shape=(trials, T))
KL_MD_sparse_trials = np.empty(shape=(trials, T))
epsilon_MD_sparse_trials = np.empty(shape=(trials, T))

SGD_sparse_trials = np.empty(shape=(trials, T))
AdaGrad_sparse_trials = np.empty(shape=(trials, T))
Vanilla_sparse_trials = np.empty(shape=(trials, T))




epsilon_for_tune = 1e-8
epsilon_in_mirror = 1e-8
eta_ = 1 / 100
c1 = 0.3
beta1_design, beta2_design = 'beta1_1', 'beta2_1'

datasize = 1000
dim = 100
noise_var = 0.05
# T = 100010


'''
generate_data 里的随机种子设置是为了保证每次进行10trials的实验的时候，都是这10组数据
main_function 里的随机种子，是我们令每次实验随机选择的一个个样本都按照特定的随机序列来，不然没办法复现
为了实验的复现，我们在这里令每次trail中的每一次迭代所选择的样本按照一个固定的随机顺序而来。

'''

for j in range(trials):
    print(j)
    X_train, y_train, y_free, w_star = generate_data(datasize, dim, noise_var, j+10)
    print(X_train[:3, :5])
    diff_w_set, error_set, n_sparse_set = main_function(X_train, y_train, X_train, y_free, T, w_star, epsilon_in_mirror, epsilon_for_tune, eta_, c1, beta1_design, beta2_design, algorithm_nums)

    L2norm_ADMD_diff_w_trials[j, :], L2norm_ADMD_error_trials[j, :], L2norm_ADMD_sparse_trials[j, :] = np.squeeze(np.array(diff_w_set[0])), np.squeeze(np.array(error_set[0])), np.squeeze(np.array(n_sparse_set[0]))
    KL_ADMD_diff_w_trials[j, :], KL_ADMD_error_trials[j, :], KL_ADMD_sparse_trials[j, :] = np.squeeze(np.array(diff_w_set[1])), np.squeeze(np.array(error_set[1])), np.squeeze(np.array(n_sparse_set[1]))
    epsilon_ADMD_diff_w_trials[j, :], epsilon_ADMD_error_trials[j, :], epsilon_ADMD_sparse_trials[j, :] = np.squeeze(np.array(diff_w_set[2])), np.squeeze(np.array(error_set[2])), np.squeeze(np.array(n_sparse_set[2]))

    L2norm_MD_diff_w_trials[j, :], L2norm_MD_error_trials[j, :], L2norm_MD_sparse_trials[j, :] = np.squeeze(np.array(diff_w_set[3])), np.squeeze(np.array(error_set[3])), np.squeeze(np.array(n_sparse_set[3]))
    KL_MD_diff_w_trials[j, :], KL_MD_error_trials[j, :], KL_MD_sparse_trials[j, :] = np.squeeze(np.array(diff_w_set[4])), np.squeeze(np.array(error_set[4])), np.squeeze(np.array(n_sparse_set[4]))
    epsilon_MD_diff_w_trials[j, :], epsilon_MD_error_trials[j, :], epsilon_MD_sparse_trials[j, :] = np.squeeze(np.array(diff_w_set[5])), np.squeeze(np.array(error_set[5])), np.squeeze(np.array(n_sparse_set[5]))

    SGD_diff_w_trials[j, :], SGD_error_trials[j, :], SGD_sparse_trials[j, :] = np.squeeze(np.array(diff_w_set[6])), np.squeeze(np.array(error_set[6])), np.squeeze(np.array(n_sparse_set[6]))
    AdaGrad_diff_w_trials[j, :], AdaGrad_error_trials[j, :], AdaGrad_sparse_trials[j, :] = np.squeeze(np.array(diff_w_set[7])), np.squeeze(np.array(error_set[7])), np.squeeze(np.array(n_sparse_set[7]))
    Vanilla_diff_w_trials[j, :], Vanilla_error_trials[j, :], Vanilla_sparse_trials[j, :] = np.squeeze(np.array(diff_w_set[8])), np.squeeze(np.array(error_set[8])), np.squeeze(np.array(n_sparse_set[8]))


# ☀️save final
Runing_result = {
    'L2norm_ADMD_diff_w_trials': L2norm_ADMD_diff_w_trials,
    'L2norm_ADMD_error_trials': L2norm_ADMD_error_trials,
    'L2norm_ADMD_sparse_trials': L2norm_ADMD_sparse_trials,
    'KL_ADMD_diff_w_trials': KL_ADMD_diff_w_trials,
    'KL_ADMD_error_trials': KL_ADMD_error_trials,
    'KL_ADMD_sparse_trials': KL_ADMD_sparse_trials,
    'epsilon_ADMD_diff_w_trials': epsilon_ADMD_diff_w_trials,
    'epsilon_ADMD_error_trials': epsilon_ADMD_error_trials,
    'epsilon_ADMD_sparse_trials': epsilon_ADMD_sparse_trials,
    'L2norm_MD_diff_w_trials': L2norm_MD_diff_w_trials,
    'L2norm_MD_error_trials': L2norm_MD_error_trials,
    'L2norm_MD_sparse_trials': L2norm_MD_sparse_trials,
    'KL_MD_diff_w_trials': KL_MD_diff_w_trials,
    'KL_MD_error_trials': KL_MD_error_trials,
    'KL_MD_sparse_trials': KL_MD_sparse_trials,
    'epsilon_MD_diff_w_trials': epsilon_MD_diff_w_trials,
    'epsilon_MD_error_trials': epsilon_MD_error_trials,
    'epsilon_MD_sparse_trials': epsilon_MD_sparse_trials,
    'SGD_diff_w_trials': SGD_diff_w_trials,
    'SGD_error_trials': SGD_error_trials,
    'SGD_sparse_trials': SGD_sparse_trials,
    'AdaGrad_diff_w_trials': AdaGrad_diff_w_trials,
    'AdaGrad_error_trials': AdaGrad_error_trials,
    'AdaGrad_sparse_trials': AdaGrad_sparse_trials,
    'Vanilla_diff_w_trials': Vanilla_diff_w_trials,
    'Vanilla_error_trials': Vanilla_error_trials,
    'Vanilla_sparse_trials': Vanilla_sparse_trials}


theorem = '1_2'
# beta1 = 'c1_di_t**-2'
beta1 = 'c1_di_t**-0.5'
beta2 = '1-1_di_T'
filename = f'../AdMD_results/Theorem{theorem}_datasize{datasize}_dim{dim}_noise_var{noise_var}_T{T}_eta{eta_}_beta1={beta1}_beta2={beta2}_c1{c1}_{trials}trials_new.npy'
np.save(filename, Runing_result)

print('------------------------------ runing information ------------------------------------------')
time_total = time.time() - time_start
print('running time:', time_total)
print(filename)
print(Runing_result.keys())

