import numpy as np
import math
import random
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter

config = {
    "font.family": 'Times New Roman',
    "font.size": 17,
    "mathtext.fontset": 'stix',
}
rcParams.update(config)



def create_y(x, w_star):
    y = np.dot(x, w_star)
    return y


def sample(train_size, dim, noise_var, seed_i):
    np.random.seed(seed_i)
    w_star = np.random.randn(dim)
    # (1)
    X_train = np.random.randn(train_size, dim)
    y_free = np.random.randn(train_size)
    # (2)
    noise = noise_var * np.random.randn(len(y_free))
    y_train_free = y_free
    y_train = y_free + noise
    return X_train.shape, y_train.shape, X_train, y_train, y_train_free, w_star





# def sample(train_size, dim, noise_var, seed_i):
#     # 生成 w_star 并确保它的 L1 范数为 1
#     np.random.seed(seed_i)
#     w_star = np.random.randn(dim)
#     # w_star = np.maximum(w_star, 0)  # 确保权重为非负
#     # w_star = w_star / np.sum(w_star)  # 归一化，确保 L1 范数为 1
#
#     # 生成训练数据 X_train
#     X_train = np.random.randn(train_size, dim)
#
#     # 使用 w_star 生成 y_train_free
#     y_train_free = create_y(X_train, w_star)
#
#     # 添加噪声
#     noise = noise_var * np.random.randn(train_size)
#     y_train = y_train_free + noise
#
#     return X_train.shape, y_train.shape, X_train, y_train, y_train_free, w_star


def generate_data(train, dim, noise_var, seed_i):
    samples = sample(train, dim, noise_var, seed_i)
    X_train, y_train, y_train_free, w_star = samples[2], samples[3], samples[4], samples[5]
    # print('\n ########### ♣️From dim = %s | noise_var=%s | Train set X:%s, y:%s | Test set X:%s, y:%s  ##########' % (dim, noise_var, samples[0], samples[1]))
    return X_train, y_train, y_train_free, w_star


''' -----------------------   2. 不同的mirror map，求偏导数，反解系数w ----------------------- '''
# --------------------- 求偏导数 ---------------------
def Grad_of_mirror_epsilon(w, epsilon_):
    grad_of_mirror = np.copy(w)
    idx_1 = np.abs(w) <= epsilon_
    idx_2 = ~idx_1
    grad_of_mirror[idx_1] = grad_of_mirror[idx_1] / epsilon_
    grad_of_mirror[idx_2] = np.sign(grad_of_mirror[idx_2])
    grad_of_mirror = grad_of_mirror + w
    return grad_of_mirror


def Grad_of_mirror_KL(w):
    # 修正：需要保证w向量中的每一个元素都是正数，并且加和为1，否则我没有办法计算np.log，也不满足KL 作为mirror map的要求
    w[w <= 0] = 1e-8
    # print(w)
    # print(w.shape)
    grad_of_mirror = 1 + np.log(w)
    return grad_of_mirror


# --------------------- 反解系数w  ---------------------
def w_from_grad_of_mirror_epsilon(grad_t, epsilon_):  # 从每次的梯度中反解出系数w
    w_from_grad = np.copy(grad_t).astype(float)
    lambda_ = 1  # 论文中没有引入多余的这个参数
    value1 = lambda_ + epsilon_
    value2 = epsilon_ / value1
    idx_1 = np.abs(grad_t) <= value1
    idx_2 = ~idx_1
    w_from_grad[idx_1] = grad_t[idx_1] * value2
    w_from_grad[idx_2] = (np.abs(grad_t[idx_2]) - lambda_) * np.sign(grad_t[idx_2])
    return w_from_grad


def w_from_grad_of_mirror_KL(grad_t):
    w_from_grad = np.exp(grad_t - 1)
    return w_from_grad


def project_to_l1_ball(w):
    """将 w 投影到 L1 范数为 1 的非负权重空间"""
    if np.sum(w) == 1 and np.all(w >= 0):
        return w  # 已经满足条件，不需要投影

    # 1. 对权重进行降序排序
    u = np.sort(w)[::-1]
    sv = np.cumsum(u)  # 计算累计和

    # 2. 计算 rho
    condition = u * np.arange(1, len(w) + 1) > (sv - 1)
    rho_indices = np.nonzero(condition)[0]
    # print(rho_indices)

    # 3. 如果没有满足条件的 rho，默认处理：直接归一化，确保权重满足 L1 范数为 1
    if len(rho_indices) == 0:
        print("Warning: No valid rho found, applying normalization as fallback.")
        return w / np.sum(w)  # 简单归一化作为备选方案

    # 4. 正常情况下找到 rho
    rho = rho_indices[-1]
    # 5. 计算 theta
    theta = (sv[rho] - 1) / (rho + 1.0)
    # 6. 执行投影
    w_proj = np.maximum(w - theta, 0)
    return w_proj


'''
方式一：确保每次迭代时权重大于 0（自适应调整机制的优势）
方式二：制造最优权重的 l1-范数为 1 的数据（处理概率分布的优势）
    w_new = np.maximum(w_new, 0)  # 确保 w 非负
    w_new = w_new / np.sum(w_new)  # 保证 L1 范数为 1             (2)直接归一化法；KL的结果直接变平变好，可能是因为wi被人为调整迅速的变好
    所有的算法都要进行这个操作
'''
def kl_divergence_update(w, grad):
    w_new = w * np.exp(-grad)
    w_new = np.maximum(w_new, 0)  # 确保 w 非负
    # w_new = project_to_l1_ball(w_new)  # 投影到 L1 范数为 1     (1) duchi 投影算法
    # w_new = w_new / np.sum(w_new)  # 保证 L1 范数为 1             (2)直接归一化法；KL的结果直接变平变好，可能是因为wi被人为调整迅速的变好
    return w_new



''' -----------------------   3. 不同算法对系数的更新方式 ----------------------- '''
# ⚠️m_current, v_current 需要赋予初始值
def mirror_descent_part_calculation(w_current, m_current, v_current, x_iter, y_iter, t_iter, T, eta_, eps_, beta1, beta2):
    # eta_ = 1 / math.sqrt(t_iter)
    # eta_ = 1 / 100
    # eps_ = 1e-8
    # c1 = 0.3  # \in (0, 1)
    # beta1 = c1 * (1 / math.sqrt(t_iter))
    # beta2 = 1 - 1 / T
    # g = (np.dot(x_iter, w_current) - y_iter) * x_iter
    # lambda1 = 0.4
    # g = (np.dot(x_iter, w_current) - y_iter) * x_iter + lambda1 * w_current

    # 定义 Non-convex Logarithmic Loss 函数
    alpha_ = 0.5
    g = -x_iter * (y_iter / (1 + np.exp(y_iter * np.dot(x_iter, w_current)))) + (2 * alpha_ * w_current) / (1 + w_current**2)
    # print(g.shape)


    m_update = beta1 * m_current + (1 - beta1) * g
    v_update = beta2 * v_current + (1 - beta2) * g ** 2
    vv = np.sqrt(v_update) + eps_
    mirror_descent_part = eta_ * m_update / vv
    return mirror_descent_part, m_update, v_update


def SGD_update(w_current, x_iter, y_iter, t_iter, eta_):  # 在第t迭代时的系数的更新
    # eta_ = 1 / 100
    # eta_ = 1 / math.sqrt(t_iter)
    # g = np.squeeze((np.dot(x_iter, w_current) - y_iter) * x_iter * eta_)
    # lambda1 = 0.4
    # g = ((np.dot(x_iter, w_current) - y_iter) * x_iter + lambda1 * w_current) * eta_

    # # 定义 Non-convex Logarithmic Loss 函数
    alpha_ = 0.5
    g = (-x_iter * (y_iter / (1 + np.exp(y_iter * np.dot(x_iter, w_current)))) + (2 * alpha_ * w_current) / (1 + w_current**2)) * eta_
    # print(g.shape)


    g = np.squeeze(g)
    w_update = w_current - g
    # w_update = np.maximum(w_update, 0)  # 确保 w 非负
    # w_update = w_update / np.sum(w_update)  # 保证 L1 范数为 1
    return w_update


def MD_update(w_current, epsilon_, x_iter, y_iter, t_iter, T, eta_, map_func):
    # （1）求mirror_descent_part, 这部分和SGD的右侧一样
    # eta_ = 1/math.sqrt(t_iter)
    # eta_ = 1 / 100
    # mirror_descent_part = (np.dot(x_iter, w_current) - y_iter) * x_iter * eta_
    # lambda1 = 0.4
    # mirror_descent_part = ((np.dot(x_iter, w_current) - y_iter) * x_iter + lambda1 * w_current) * eta_

    # 定义 Non-convex Logarithmic Loss 函数
    alpha_ = 0.5
    mirror_descent_part = (-x_iter * (y_iter / (1 + np.exp(y_iter * np.dot(x_iter, w_current)))) + (2 * alpha_ * w_current) / (1 + w_current**2)) * eta_
    # print(mirror_descent_part.shape)

    # （2）求关于mirror map的导数
    if map_func == 'mirror_epsilon':
        grad_mirror = Grad_of_mirror_epsilon(w_current, epsilon_)
        grad_mirror_new = grad_mirror - mirror_descent_part
    if map_func == 'mirror_L2norm':  # 也就是Adam
        grad_mirror = w_current
        grad_mirror_new = grad_mirror - mirror_descent_part

    # （4）反解出系数w
    if map_func == 'mirror_epsilon':
        w_update = w_from_grad_of_mirror_epsilon(grad_mirror_new, epsilon_)
    if map_func == 'mirror_KL':
        # w_update = w_from_grad_of_mirror_KL(grad_mirror_new)
        w_update = kl_divergence_update(w_current, mirror_descent_part)
    if map_func == 'mirror_L2norm':
        w_update = grad_mirror_new

    # w_update = np.maximum(w_update, 0)  # 确保 w 非负
    # w_update = w_update / np.sum(w_update)  # 保证 L1 范数为 1
    w_update = np.squeeze(w_update)
    return w_update



def AdMD_update(w_current, m_current, v_current, epsilon_, x_iter, y_iter, t_iter, T, eta_, eps_, beta1, beta2, map_func):
    # （1）求m,v的部分，统称为mirror_descent_part
    mirror_descent_part, m_update, v_update = mirror_descent_part_calculation(w_current, m_current, v_current, x_iter,
                                                                              y_iter, t_iter, T, eta_, eps_, beta1, beta2)
    # （2）求关于mirror map的导数
    if map_func == 'mirror_epsilon':
        grad_mirror = Grad_of_mirror_epsilon(w_current, epsilon_)
        grad_mirror_new = grad_mirror - mirror_descent_part
    if map_func == 'mirror_L2norm':  # 也就是Adam
        grad_mirror = w_current
        grad_mirror_new = grad_mirror - mirror_descent_part

    # （4）反解出系数w
    if map_func == 'mirror_epsilon':
        w_update = w_from_grad_of_mirror_epsilon(grad_mirror_new, epsilon_)
    if map_func == 'mirror_KL':
        # w_update = w_from_grad_of_mirror_KL(grad_mirror_new)
        w_update = kl_divergence_update(w_current, mirror_descent_part)

    if map_func == 'mirror_L2norm':
        w_update = grad_mirror_new

    # w_update = np.maximum(w_update, 0)  # 确保 w 非负
    # w_update = w_update / np.sum(w_update)  # 保证 L1 范数为 1
    w_update = np.squeeze(w_update)
    return w_update, m_update, v_update


def AdaGrad_descent_part_calculation(w_current, v_current, x_iter, y_iter, T, t_iter, eta_, eps_):
    # eta_ = 1 / math.sqrt(t_iter) # 这个结果也会稍微好一些
    # eta_ = 1 / 100 # 这个结果很差，是因为，vt=g^2所造成的步伐会很小，而我们的AdMD的步伐只是0.0001* g^2,也就是步伐很大，所以我们调大步伐，不妨假设步伐为1/T
    # eta_ = 0.5  # 我们要么把eta变大，要么给AdaGrad的Vt加一个系数，但是为了不损失它的定义，我们决定改变eta
    # eps_ = 1e-8
    # g = (np.dot(x_iter, w_current) - y_iter) * x_iter
    lambda1 = 0.4
    g = (np.dot(x_iter, w_current) - y_iter) * x_iter + lambda1 * w_current


    m_update = g
    v_update = v_current + g ** 2  # g**2 的加和
    vv = np.sqrt(v_update) + eps_
    mirror_descent_part = eta_ * m_update / vv
    return mirror_descent_part, v_update


def AdaGrad_update(w_current, v_current, x_iter, y_iter, T, t_iter, eta_, epsilon_for_tune):
    mirror_descent_part, v_update = AdaGrad_descent_part_calculation(w_current, v_current, x_iter, y_iter, T, t_iter, eta_, epsilon_for_tune)
    w_update = w_current - mirror_descent_part
    # w_update = np.maximum(w_update, 0)  # 确保 w 非负
    # w_update = w_update / np.sum(w_update)  # 保证 L1 范数为 1
    w_update = np.squeeze(w_update)
    return w_update, v_update



def mirror_descent_part_calculation_for_vanilla(w_current, m_current, v_current, x_iter, y_iter, t_iter, T, eta_, eps_, beta1, beta2):
    # eta_ = 1 / 100
    # eps_ = 1e-8
    # c1 = 0.3  # \in (0, 1)
    # beta1 = c1 * (1 / math.sqrt(t_iter))
    # beta2 = 1 - 1 / T
    # g = (np.dot(x_iter, w_current) - y_iter) * x_iter

    # 定义 Non-convex Logarithmic Loss 函数
    alpha_ = 0.5
    g = -x_iter * (y_iter / (1 + np.exp(y_iter * np.dot(x_iter, w_current)))) + (2 * alpha_ * w_current) / (1 + w_current**2)
    # print(g.shape)

    m_update = beta1 * m_current + (1 - beta1) * g
    v_update = beta2 * v_current + (1 - beta2) * g ** 2

    # 偏差纠正
    # m_update = m_update / (1-beta1**t_iter)
    # v_update = v_update / (1-beta2**t_iter)
    # print(t_iter)
    # print(1-beta2**t_iter)

    vv = np.sqrt(v_update) + eps_
    mirror_descent_part = eta_ * m_update / vv
    return mirror_descent_part, m_update, v_update


def vanilla_AdMD_update(w_current, m_current, v_current, x_iter, y_iter, t_iter, T, eta_, eps_, beta1, beta2):
    mirror_descent_part, m_update, v_update = mirror_descent_part_calculation_for_vanilla(w_current, m_current, v_current, x_iter, y_iter, t_iter, T, eta_, eps_, beta1, beta2)
    w_update = w_current - mirror_descent_part

    # w_update = np.maximum(w_update, 0)  # 确保 w 非负
    # w_update = w_update / np.sum(w_update)  # 保证 L1 范数为 1
    w_update = np.squeeze(w_update)
    # print('w_update.shape', w_update.shape)
    return w_update, m_update, v_update




def main_function(x, y, x_for_test, y_for_test, T, w_star, epsilon_in_mirror, epsilon_for_tune, eta_, c1, beta1_design, beta2_design, algorithm_nums):

    x_size, x_dim = x.shape[0], x.shape[1],
    w_current = np.random.randn(x_dim) # 生成一个或多个在 [0,1) 区间均匀分布的随机数
    # w_current /= np.sum(w_current)  # 归一化，使 L1 范数为

    w_current_SGD, w_current_L2norm_AdMD, w_current_KL_AdMD, w_current_epsilon_AdMD, w_current_vanilla_adam = w_current, w_current, w_current, w_current, w_current
    w_current_L2norm_MD, w_current_KL_MD, w_current_epsilon_MD, w_current_AdaGrad = w_current, w_current, w_current, w_current
    m_current_L2norm, v_current_L2norm, m_current_KL, v_current_KL, m_current_epsilon, v_current_epsilon, m_current_vanilla_adam, v_current_vanilla_adam = np.zeros(
        x_dim), np.zeros(x_dim), np.zeros(x_dim), np.zeros(x_dim), np.zeros(x_dim), np.zeros(x_dim), np.zeros(x_dim), np.zeros(x_dim)
    v_current_AdaGrad = np.zeros(x_dim)

    # 用来存放每一次迭代后的结果
    diff_w_set = np.zeros((algorithm_nums, T))
    error_set = np.zeros((algorithm_nums, T))
    n_sparse_set = np.zeros((algorithm_nums, T))
    norm_star = np.linalg.norm(w_star)

    for i in range(1, T + 1):
        t_iter = i
        if beta1_design == 'beta1_a' and beta2_design == 'beta2_a':
            # print('beta1_a, beta2_a')
            eta_ = 1 / math.sqrt(T)
            beta1 = 1 - 1 / math.sqrt(T)
            beta2 = 1 - 1 / T

        if beta1_design == 'beta1_b' and beta2_design == 'beta2_b':
            # print('beta1_b, beta2_b')
            eta_ = 1 / math.sqrt(t_iter)
            beta1 = 1 - 1 / math.sqrt(t_iter)
            beta2 = 1 - t_iter ** (-2)

        np.random.seed(t_iter)
        idx = np.random.randint(x_size, size=1)  # 每次随机选取的样本
        x_iter = x[idx]
        y_iter = y[idx]

        w_current_SGD = SGD_update(w_current_SGD, x_iter, y_iter, t_iter, eta_)
        w_current_AdaGrad, v_current_AdaGrad = AdaGrad_update(w_current_AdaGrad, v_current_AdaGrad, x_iter, y_iter, T, t_iter, eta_, epsilon_for_tune)
        w_current_vanilla_adam, m_current_vanilla_adam, v_current_vanilla_adam = vanilla_AdMD_update(w_current_vanilla_adam, m_current_vanilla_adam, v_current_vanilla_adam, x_iter, y_iter, t_iter, T, eta_, epsilon_for_tune, beta1, beta2)

        w_current_L2norm_MD = MD_update(w_current_L2norm_MD, epsilon_in_mirror, x_iter, y_iter, t_iter, T, eta_, map_func='mirror_L2norm')
        w_current_KL_MD = MD_update(w_current_KL_MD, epsilon_in_mirror, x_iter, y_iter, t_iter, T, eta_, map_func='mirror_KL')
        w_current_epsilon_MD = MD_update(w_current_epsilon_MD, epsilon_in_mirror, x_iter, y_iter, t_iter, T, eta_, map_func='mirror_epsilon')


        w_current_L2norm_AdMD, m_current_L2norm, v_current_L2norm = AdMD_update(w_current_L2norm_AdMD, m_current_L2norm, v_current_L2norm, epsilon_in_mirror, x_iter, y_iter, t_iter, T, eta_, epsilon_for_tune, beta1, beta2, map_func='mirror_L2norm')
        w_current_KL_AdMD, m_current_KL, v_current_KL = AdMD_update(w_current_KL_AdMD, m_current_KL, v_current_KL, epsilon_in_mirror, x_iter, y_iter, t_iter, T, eta_, epsilon_for_tune, beta1, beta2, map_func='mirror_KL')
        w_current_epsilon_AdMD, m_current_epsilon, v_current_epsilon = AdMD_update(w_current_epsilon_AdMD, m_current_epsilon, v_current_epsilon, epsilon_in_mirror, x_iter, y_iter, t_iter, T, eta_, epsilon_for_tune, beta1, beta2, map_func='mirror_epsilon')


        # （1） 记录系数的差别
        diff_w_MdMD_L2norm = w_current_L2norm_AdMD - w_star
        diff_w_MdMD_KL = w_current_KL_AdMD - w_star
        diff_w_MdMD_epsilon = w_current_epsilon_AdMD - w_star

        diff_w_MD_L2norm = w_current_L2norm_MD - w_star
        diff_w_MD_KL = w_current_KL_MD - w_star
        diff_w_MD_epsilon = w_current_epsilon_MD - w_star

        diff_w_SGD = w_current_SGD - w_star
        diff_w_AdaGrad = w_current_AdaGrad - w_star
        diff_w_vanilla = w_current_vanilla_adam - w_star


        diff_w_set[0, i - 1] = np.linalg.norm(diff_w_MdMD_L2norm) / norm_star
        diff_w_set[1, i - 1] = np.linalg.norm(diff_w_MdMD_KL) / norm_star
        diff_w_set[2, i - 1] = np.linalg.norm(diff_w_MdMD_epsilon) / norm_star

        diff_w_set[3, i - 1] = np.linalg.norm(diff_w_MD_L2norm) / norm_star
        diff_w_set[4, i - 1] = np.linalg.norm(diff_w_MD_KL) / norm_star
        diff_w_set[5, i - 1] = np.linalg.norm(diff_w_MD_epsilon) / norm_star

        diff_w_set[6, i - 1] = np.linalg.norm(diff_w_SGD) / norm_star
        diff_w_set[7, i - 1] = np.linalg.norm(diff_w_AdaGrad) / norm_star
        diff_w_set[8, i - 1] = np.linalg.norm(diff_w_vanilla) / norm_star


        # （2） 记录迭代后的系数在无噪音的训练数据伤的误差
        # 在无噪音的训练数据上测试误差时，输入的x_for_test, y_for_test是：x, y_train_f
        # 在测试数据上测试误差时，输入的x_for_test, y_for_test是：x_test, y_test
        error_set[0, i - 1] = np.sum((np.dot(x_for_test, w_current_L2norm_AdMD) - y_for_test) ** 2) / x_for_test.shape[0]
        error_set[1, i - 1] = np.sum((np.dot(x_for_test, w_current_KL_AdMD) - y_for_test) ** 2) / x_for_test.shape[0]
        error_set[2, i - 1] = np.sum((np.dot(x_for_test, w_current_epsilon_AdMD) - y_for_test) ** 2) / x_for_test.shape[0]

        error_set[3, i - 1] = np.sum((np.dot(x_for_test, w_current_L2norm_MD) - y_for_test) ** 2) / x_for_test.shape[0]
        error_set[4, i - 1] = np.sum((np.dot(x_for_test, w_current_KL_MD) - y_for_test) ** 2) / x_for_test.shape[0]
        error_set[5, i - 1] = np.sum((np.dot(x_for_test, w_current_epsilon_MD) - y_for_test) ** 2) / x_for_test.shape[0]

        error_set[6, i - 1] = np.sum((np.dot(x_for_test, w_current_SGD) - y_for_test) ** 2) / x_for_test.shape[0]
        error_set[7, i - 1] = np.sum((np.dot(x_for_test, w_current_AdaGrad) - y_for_test) ** 2) / x_for_test.shape[0]
        error_set[8, i - 1] = np.sum((np.dot(x_for_test, w_current_vanilla_adam) - y_for_test) ** 2) / x_for_test.shape[0]


        # （3） 记录每一次迭代后的系数的非零元素的个数
        n_sparse_set[0, i - 1] = np.sum(np.abs(w_current_L2norm_MD) > 1e-8)
        n_sparse_set[1, i - 1] = np.sum(np.abs(w_current_KL_MD) > 1e-8)
        n_sparse_set[2, i - 1] = np.sum(np.abs(w_current_epsilon_MD) > 1e-8)

        n_sparse_set[3, i - 1] = np.sum(np.abs(w_current_L2norm_AdMD) > 1e-8)
        n_sparse_set[4, i - 1] = np.sum(np.abs(w_current_KL_AdMD) > 1e-8)
        n_sparse_set[5, i - 1] = np.sum(np.abs(w_current_epsilon_AdMD) > 1e-8)

        n_sparse_set[6, i - 1] = np.sum(np.abs(w_current_SGD) > 1e-8)
        n_sparse_set[7, i - 1] = np.sum(np.abs(w_current_AdaGrad) > 1e-8)
        n_sparse_set[8, i - 1] = np.sum(np.abs(w_current_vanilla_adam) > 1e-8)

        # print('sparse of w_star', np.sum(np.abs(w_star) > 1e-8))

    print(diff_w_set.shape)
    print(error_set.shape)
    print(n_sparse_set.shape)
    return diff_w_set, error_set, n_sparse_set



## -----------------------------（2）✅-----------------------------


# random.seed(7)
# epsilon_for_tune = 1e-8
# epsilon_in_mirror = 1e-8
# eta_ = 1 / 100
# c1 = 0.3  # \in (0, 1)
# beta1_design, beta2_design = 'beta1_b', 'beta2_b'
#
# train = 1000
# dim = 100
# noise_var = 0.05
# # T = 100010
# T = 5010
# algorithm_nums = 9
# seed_i = 17
# X_train, y_train, y_free, w_star = generate_data(train, dim, noise_var, seed_i)
# diff_w_set, error_set, n_sparse_set = main_function(X_train, y_train, X_train, y_free, T, w_star, epsilon_in_mirror, epsilon_for_tune, eta_, c1, beta1_design, beta2_design, algorithm_nums)
#
#
# #
# #
# #
# # np.set_printoptions(threshold=np.inf)
# # print('----------------------------- AdMD Algorithms ------------------------------')
# # print('L2_ADMD', error_set[0, T - 10:T])
# # print('KL_ADMD', error_set[1, T - 10:T])
# # print('epsilon_ADMD', error_set[2, T - 10:T])
# # print('----------------------------- MD Algorithms ------------------------------')
# # print('L2_MD', error_set[3, T - 10:T])
# # print('KL_MD', error_set[4, T - 10:T])
# # print('epsilon_MD', error_set[5, T - 10:T])
# # print('----------------------------- Other Algorithms ------------------------------')
# # print('SGD', error_set[6, T - 10:T])
# # print('AdaGrad', error_set[7, T - 10:T])
# # print('Vanilla Adam', error_set[8, T - 10:T])
# #
# #
# #
# #
# # '''------------------------------  画图  ------------------------------'''
# T_list = [i for i in range(1, T+1, 1)]
#
# num_points = 100
# # 生成对数间隔的索引，保证索引在 1 到 T 之间
# indices = np.unique(np.logspace(0, np.log10(T), num=num_points, dtype=int)) - 1
# # 防止索引超出范围（因为有时候可能会有T以外的数）
# indices = np.clip(indices, 0, T - 1)
#
#
# fig = plt.figure(tight_layout=True)
# fig = plt.figure(figsize=(6, 5), tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.set_ylabel('Error', fontsize='15')
# # ax.set_xlabel('Iterations \n (Uniformly sampling, $N=1000, d=100, \\sigma=0.05$)', fontsize='15')
# # ax.set_xlabel('Iterations ($\\beta_{2,t}=1-t^{-2}$) \n (Normal distribution sampling, $N=1000, d=100, \\sigma=0.05$)', fontsize='15')
# ax.set_xlabel('Iterations ($\\beta_{2,t}=1-1/T$) \n (Normal distribution sampling, $N=1000, d=100, \\sigma=0.05$)',
#               fontsize='15')
#
# # ax.plot(T_list, error_set[0], c='green', linestyle='-', linewidth=1.2, label='AdMD with $\\Psi^{(\ell^2)}(\mathbf{w})$')
# # ax.plot(T_list, error_set[1], c='orange', linestyle='-', linewidth=1.2, label='AdMD with $\\Psi^{(KL)}(\mathbf{w})$')
# # ax.plot(T_list, error_set[2], c='purple', linestyle='-', linewidth=1.2, label='AdMD with $\\Psi^{(\\epsilon)}(\mathbf{w})$')
# #
# # ax.plot(T_list, error_set[3], c='green', linestyle='--', linewidth=1.2, label='MD with $\\Psi^{(\ell^2)}(\mathbf{w})$')
# # ax.plot(T_list, error_set[4], c='orange', linestyle='--', linewidth=1.2, label='MD with $\\Psi^{(KL)}(\mathbf{w})$')
# # ax.plot(T_list, error_set[5], c='purple', linestyle='--', linewidth=1.2, label='MD with $\\Psi^{(\\epsilon)}(\mathbf{w})$')
# #
# # ax.plot(T_list, error_set[6], c='royalblue', linestyle='-', linewidth=1.2, label='SGD ($\\eta_t=0.01$)')
# # ax.plot(T_list, error_set[7], c='blue', linestyle='-', linewidth=1.2, label='AdaGrad ($\\eta_t=0.5$)')
# # ax.plot(T_list, error_set[8], c='black', linestyle='-', linewidth=1.2, label='Vanilla Adam')
#
#
# ax.plot(indices, error_set[0][indices], c='green', linestyle='-', linewidth=1.2, label='AdMD with $\\Psi^{(\ell^2)}(\mathbf{w})$')
# # ax.plot(indices, error_set[1][indices], c='orange', linestyle='-', linewidth=1.2, label='AdMD with $\\Psi^{(KL)}(\mathbf{w})$')
# # ax.plot(indices, error_set[2][indices], c='purple', linestyle='-', linewidth=1.2, label='AdMD with $\\Psi^{(\\epsilon)}(\mathbf{w})$')
#
# # ax.plot(indices, error_set[3][indices], c='red', linestyle='--', linewidth=1.2, label='MD with $\\Psi^{(\ell^2)}(\mathbf{w})$ (SGD)')
# # ax.plot(indices, error_set[4][indices], c='orange', linestyle='--', linewidth=1.2, label='MD with $\\Psi^{(KL)}(\mathbf{w})$')
# # ax.plot(indices, error_set[5][indices], c='purple', linestyle='--', linewidth=1.2, label='MD with $\\Psi^{(\\epsilon)}(\mathbf{w})$')
#
# ax.plot(indices, error_set[6][indices], c='royalblue', linestyle='-', linewidth=1.2, label='SGD ($\\eta_t=0.01$)') # = error_set[3][indices] MD L2norm
# # ax.plot(indices, error_set[7][indices], c='blue', linestyle='-', linewidth=1.2, label='AdaGrad ($\\eta_t=0.5$)')
# # ax.plot(indices, error_set[8][indices], c='black', linestyle='-', linewidth=1.2, label='Vanilla Adam')  # =error_set[0][indices] AdMD, L2norm, 没有调整时
#
#
# # plt.legend(ncol=4, loc='upper center', bbox_to_anchor=(0.5, -0.1), fontsize='13')
#
# plt.yscale('log')
# plt.xscale('log')
# # plt.ylim(0, 50) # d= 3
# ax.legend(ncol=1, loc='lower left', fontsize='8')
# plt.show()
