import numpy as np
import math
import random
import os, time
from numpy import *
import matplotlib.pyplot as plt

from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
config = {
    "font.family":'Times New Roman',
    "font.size": 17,
    "mathtext.fontset":'stix',
}
rcParams.update(config)




'''
def sample(train_size, dim, noise_var, seed_i):
    # 生成 w_star 并确保它的 L1 范数为 1
    np.random.seed(seed_i)
    w_star = np.random.randn(dim)
    w_star = np.maximum(w_star, 0)  # 确保权重为非负
    w_star = w_star / np.sum(w_star)  # 归一化，确保 L1 范数为 1
'''
epsilon_for_tune = 1e-8
epsilon_in_mirror = 1e-8
datasize = 1000
dim = 100
T = 100100
trials = 10
# noise_var = 0.05
noise_var = 2

c1 = 0.3
eta_ = 1 / 100

theorem = '3'
# beta1 = 'c1_di_t**-0.5'
# beta2 = '1-1_di_t**-2'
# beta1 = 'c1_di_t__-0.5'
# beta2 = '1-1_di_t__-2'
# filename_load = f'../AdMD_results/Theorem{theorem}_nostar_datasize{datasize}_dim{dim}_noise_var{noise_var}_T{T}_eta{eta_}_beta1={beta1}_beta2={beta2}_c1{c1}_{trials}trials_new.npy'

beta1 = 'c1_di_t'
beta2 = '1-1_di_t__-2'



filename_load = f'../AdMD_results/Theorem3_nostar_datasize1000_dim100_noise_var2_T100100_eta0.01_beta1=c1_di_t_beta2=1-1_di_t__-2_c10.3_10trials_newnew.npy'



# filename_load = f'../AdMD_results/Theorem{theorem}_Without_wstar_datasize{datasize}_dim{dim}_noise_var{noise_var}_T{T}_eta{eta_}_beta1={beta1}_beta2={beta2}_c1{c1}_{trials}trials.npy' # labmda=0.8
# filename_load = f'../AdMD_results/Theorem{theorem}_Without_wstar_datasize{datasize}_dim{dim}_noise_var{noise_var}_T{T}_eta{eta_}_beta1={beta1}_beta2={beta2}_c1{c1}_{trials}trials_lambda04.npy'
AdMD_result = np.load(filename_load, allow_pickle=True).item()
L2norm_ADMD_diff_w_trials_mean = np.mean(AdMD_result['L2norm_ADMD_diff_w_trials'], axis=0)
L2norm_ADMD_error_trials_mean = np.mean(AdMD_result['L2norm_ADMD_error_trials'], axis=0)
L2norm_ADMD_sparse_trials_mean = np.mean(AdMD_result['L2norm_ADMD_sparse_trials'], axis=0)

KL_ADMD_diff_w_trials_mean = np.mean(AdMD_result['KL_ADMD_diff_w_trials'], axis=0)
KL_ADMD_error_trials_mean = np.mean(AdMD_result['KL_ADMD_error_trials'], axis=0)
KL_ADMD_sparse_trials_mean = np.mean(AdMD_result['KL_ADMD_sparse_trials'], axis=0)

epsilon_ADMD_diff_w_trials_mean = np.mean(AdMD_result['epsilon_ADMD_diff_w_trials'], axis=0)
epsilon_ADMD_error_trials_mean = np.mean(AdMD_result['epsilon_ADMD_error_trials'], axis=0)
epsilon_ADMD_sparse_trials_mean = np.mean(AdMD_result['epsilon_ADMD_sparse_trials'], axis=0)

L2norm_MD_diff_w_trials_mean = np.mean(AdMD_result['L2norm_MD_diff_w_trials'], axis=0)
L2norm_MD_error_trials_mean = np.mean(AdMD_result['L2norm_MD_error_trials'], axis=0)
L2norm_MD_sparse_trials_mean = np.mean(AdMD_result['L2norm_MD_sparse_trials'], axis=0)

KL_MD_diff_w_trials_mean = np.mean(AdMD_result['KL_MD_diff_w_trials'], axis=0)
KL_MD_error_trials_mean = np.mean(AdMD_result['KL_MD_error_trials'], axis=0)
KL_MD_sparse_trials_mean = np.mean(AdMD_result['KL_MD_sparse_trials'], axis=0)

epsilon_MD_diff_w_trials_mean = np.mean(AdMD_result['epsilon_MD_diff_w_trials'], axis=0)
epsilon_MD_error_trials_mean = np.mean(AdMD_result['epsilon_MD_error_trials'], axis=0)
epsilon_MD_sparse_trials_mean = np.mean(AdMD_result['epsilon_MD_sparse_trials'], axis=0)

SGD_diff_w_trials_mean = np.mean(AdMD_result['SGD_diff_w_trials'], axis=0)
SGD_error_trials_mean = np.mean(AdMD_result['SGD_error_trials'], axis=0)
SGD_sparse_trials_mean = np.mean(AdMD_result['SGD_sparse_trials'], axis=0)

AdaGrad_diff_w_trials_mean = np.mean(AdMD_result['AdaGrad_diff_w_trials'], axis=0)
AdaGrad_error_trials_mean = np.mean(AdMD_result['AdaGrad_error_trials'], axis=0)
AdaGrad_sparse_trials_mean = np.mean(AdMD_result['AdaGrad_sparse_trials'], axis=0)

Vanilla_diff_w_trials_mean = np.mean(AdMD_result['Vanilla_diff_w_trials'], axis=0)
Vanilla_error_trials_mean = np.mean(AdMD_result['Vanilla_error_trials'], axis=0)
Vanilla_sparse_trials_mean = np.mean(AdMD_result['Vanilla_sparse_trials'], axis=0)

# 1081
print(Vanilla_diff_w_trials_mean.shape)
print(AdaGrad_diff_w_trials_mean.shape)




'''------------------------------  画图  ------------------------------'''
indices = [i for i in range(1, T+1, 1)]

num_points = 100
# 生成对数间隔的索引，保证索引在 1 到 T 之间
indices = np.unique(np.logspace(0, np.log10(T), num=num_points, dtype=int)) - 1
# 防止索引超出范围（因为有时候可能会有T以外的数）
indices = np.clip(indices, 0, T - 1)
print(indices)

fig = plt.figure(tight_layout=True)
fig = plt.figure(figsize=(6, 5), tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])


'''------------------- 1. error -------------------'''
ax.set_ylabel('Error', fontsize='17')
ax.set_xlabel('Iterations \n($\\beta_{1,t}=t^{-1}, \\beta_{2,t}=1-t^{-2}, \\eta_t\equiv0.01, \\sigma=2.0$)',
              fontsize='17')
ax.plot(indices, L2norm_ADMD_error_trials_mean[indices], c='royalblue', linestyle='-', linewidth=1.2, label='AdMD$_{\\Psi^{(\ell^2)}(\mathbf{w})}$')
# ax.plot(indices, KL_ADMD_error_trials_mean[indices], c='brown', linestyle='-', linewidth=1.2, label='AdMD$_{\\Psi^{(KL)}(\mathbf{w})}$')
ax.plot(indices, epsilon_ADMD_error_trials_mean[indices], c='purple', linestyle='-', linewidth=1.2, label='AdMD$_{\\Psi^{(\\epsilon)}(\mathbf{w})}$')

ax.plot(indices, L2norm_MD_error_trials_mean[indices], c='royalblue', linestyle='--', linewidth=1.2, label='MD$_{\\Psi^{(\ell^2)}(\mathbf{w})}$')
# ax.plot(indices, KL_MD_error_trials_mean[indices], c='brown', linestyle='--', linewidth=1.2, label='MD$_{\\Psi^{(KL)}(\mathbf{w})}$')
ax.plot(indices, epsilon_MD_error_trials_mean[indices], c='purple', linestyle='--', linewidth=1.2, label='MD$_{\\Psi^{(\\epsilon)}(\mathbf{w})}$')

# ax.plot(indices, SGD_error_trials_mean[indices], c='royalblue', linestyle='-', linewidth=1.2, label='SGD ($\\eta_t=0.01$)') # = error_set[3][indices] MD L2norm
ax.plot(indices, AdaGrad_error_trials_mean[indices], c='blue', linestyle='-', linewidth=1.2, label='AdaGrad')
# ax.plot(indices, Vanilla_diff_w_trials_mean[indices], c='black', linestyle='-', linewidth=1.2, label='Vanilla Adam')  # =error_set[0][indices] AdMD, L2norm, 没有调整时

# plt.legend(ncol=4, loc='upper center', bbox_to_anchor=(0.5, -0.1), fontsize='13')
plt.yscale('log')
plt.xscale('log')
plt.xlim(10, 100100) # d= 3

ax.legend(ncol=1, loc='upper right', fontsize='15')
plt.tight_layout()
# plt.savefig(f'../AdMD_figures/Theorem3_Other_error_Without_wstar_datasize{datasize}_dim{dim}_noise_var{noise_var}_T{T}_eta{eta_}_beta1={beta1}_beta2={beta2}_c1{c1}_{trials}trials.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()


