import numpy as np
import math
import random
import os, time
from numpy import *
import matplotlib.pyplot as plt
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
config = {
    "font.family":'Times New Roman',
    "font.size": 17,
    "mathtext.fontset":'stix',
}
rcParams.update(config)



datasize = 1000
dim = 100
T = 100010
trials = 10
# noise_var = 0.05
noise_var = 2

c1 = 0.3
eta_ = 1 / 100
theorem = '4'
setting = 'a'
beta1_design, beta2_design = 'beta1_a', 'beta2_a'
#setting = 'b'
#beta1_design, beta2_design = 'beta1_b', 'beta2_b'
filename_load_logcoshloss_a = f'../AdMD_results/Theorem{theorem}_Without_wstar_datasize{datasize}_dim{dim}_noise_var{noise_var}_T{T}_{trials}trials_logcoshloss_setting{setting}.npy'
AdMD_result_logcoshloss_a = np.load(filename_load_logcoshloss_a, allow_pickle=True).item()
L2norm_ADMD_diff_w_trials_mean_logcoshloss_a = np.mean(AdMD_result_logcoshloss_a['L2norm_ADMD_diff_w_trials'], axis=0)
L2norm_ADMD_error_trials_mean_logcoshloss_a = np.mean(AdMD_result_logcoshloss_a['L2norm_ADMD_error_trials'], axis=0)
L2norm_ADMD_sparse_trials_mean_logcoshloss_a = np.mean(AdMD_result_logcoshloss_a['L2norm_ADMD_sparse_trials'], axis=0)
SGD_diff_w_trials_mean_logcoshloss_a = np.mean(AdMD_result_logcoshloss_a['SGD_diff_w_trials'], axis=0)
SGD_error_trials_mean_logcoshloss_a = np.mean(AdMD_result_logcoshloss_a['SGD_error_trials'], axis=0)
SGD_sparse_trials_mean_logcoshloss_a = np.mean(AdMD_result_logcoshloss_a['SGD_sparse_trials'], axis=0)


filename_load_logloss_a = f'../AdMD_results/Theorem{theorem}_Without_wstar_datasize{datasize}_dim{dim}_noise_var{noise_var}_T{T}_{trials}trials_logloss_setting{setting}.npy'
AdMD_result_logloss_a = np.load(filename_load_logloss_a, allow_pickle=True).item()
L2norm_ADMD_diff_w_trials_mean_logloss_a = np.mean(AdMD_result_logloss_a['L2norm_ADMD_diff_w_trials'], axis=0)
L2norm_ADMD_error_trials_mean_logloss_a = np.mean(AdMD_result_logloss_a['L2norm_ADMD_error_trials'], axis=0)
L2norm_ADMD_sparse_trials_mean_logloss_a = np.mean(AdMD_result_logloss_a['L2norm_ADMD_sparse_trials'], axis=0)
SGD_diff_w_trials_mean_logloss_a = np.mean(AdMD_result_logloss_a['SGD_diff_w_trials'], axis=0)
SGD_error_trials_mean_logloss_a = np.mean(AdMD_result_logloss_a['SGD_error_trials'], axis=0)
SGD_sparse_trials_mean_logloss_a = np.mean(AdMD_result_logloss_a['SGD_sparse_trials'], axis=0)

#
# setting = 'b'
# beta1_design, beta2_design = 'beta1_b', 'beta2_b'
# filename_load_logcoshloss_b = f'../AdMD_results/Theorem{theorem}_Without_wstar_datasize{datasize}_dim{dim}_noise_var{noise_var}_T{T}_{trials}trials_logcoshloss_setting{setting}.npy'
# AdMD_result_logcoshloss_b = np.load(filename_load_logcoshloss_b, allow_pickle=True).item()
# L2norm_ADMD_diff_w_trials_mean_logcoshloss_b = np.mean(AdMD_result_logcoshloss_b['L2norm_ADMD_diff_w_trials'], axis=0)
# L2norm_ADMD_error_trials_mean_logcoshloss_b = np.mean(AdMD_result_logcoshloss_b['L2norm_ADMD_error_trials'], axis=0)
# L2norm_ADMD_sparse_trials_mean_logcoshloss_b = np.mean(AdMD_result_logcoshloss_b['L2norm_ADMD_sparse_trials'], axis=0)
# SGD_diff_w_trials_mean_logcoshloss_b = np.mean(AdMD_result_logcoshloss_b['SGD_diff_w_trials'], axis=0)
# SGD_error_trials_mean_logcoshloss_b = np.mean(AdMD_result_logcoshloss_b['SGD_error_trials'], axis=0)
# SGD_sparse_trials_mean_logcoshloss_b = np.mean(AdMD_result_logcoshloss_b['SGD_sparse_trials'], axis=0)
#

# filename_load_logloss_b = f'../AdMD_results/Theorem{theorem}_Without_wstar_datasize{datasize}_dim{dim}_noise_var{noise_var}_T{T}_{trials}trials_logloss_setting{setting}.npy'
# AdMD_result_logloss_b = np.load(filename_load_logloss_b, allow_pickle=True).item()
# L2norm_ADMD_diff_w_trials_mean_logloss_b = np.mean(AdMD_result_logloss_b['L2norm_ADMD_diff_w_trials'], axis=0)
# L2norm_ADMD_error_trials_mean_logloss_b = np.mean(AdMD_result_logloss_b['L2norm_ADMD_error_trials'], axis=0)
# L2norm_ADMD_sparse_trials_mean_logloss_b = np.mean(AdMD_result_logloss_b['L2norm_ADMD_sparse_trials'], axis=0)
# SGD_diff_w_trials_mean_logloss_b = np.mean(AdMD_result_logloss_b['SGD_diff_w_trials'], axis=0)
# SGD_error_trials_mean_logloss_b = np.mean(AdMD_result_logloss_b['SGD_error_trials'], axis=0)
# SGD_sparse_trials_mean_logloss_b = np.mean(AdMD_result_logloss_b['SGD_sparse_trials'], axis=0)




'''------------------------------  画图  ------------------------------'''
indices = [i for i in range(1, T+1, 1)]

num_points = 100
# 生成对数间隔的索引，保证索引在 1 到 T 之间
indices = np.unique(np.logspace(0, np.log10(T), num=num_points, dtype=int)) - 1
# 防止索引超出范围（因为有时候可能会有T以外的数）
indices = np.clip(indices, 0, T - 1)
print(indices)

fig = plt.figure(tight_layout=True)
fig = plt.figure(figsize=(6, 5), tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])

'''------------------- 1. error -------------------'''
ax.set_ylabel('Error', fontsize='17')
# ax.set_xlabel('Iterations \n (Uniformly sampling, $N=1000, d=100, \\sigma=0.05$)', fontsize='15')
# ax.set_xlabel('Iterations ($\\beta_{2,t}=1-t^{-2}$) \n (Normal distribution sampling, $N=1000, d=100, \\sigma=0.05$)', fontsize='15')
ax.set_xlabel('Iterations \n($\\beta_{1,t}\equiv 1-T^{-1/2}, \\beta_{2,t}\equiv 1-T^{-1}, \\eta_t\equiv T^{-1/2}, \\sigma=2.0$)',
               fontsize='17')
# ax.set_xlabel('Iterations (setting (b), log loss function) \n (Normal distribution sampling, $N=1000, d=100, \\sigma=0.05$ \n $trials=10, T=5000$)',
 #              fontsize='12')
ax.plot(indices, L2norm_ADMD_error_trials_mean_logcoshloss_a[indices], c='royalblue', linestyle='-', linewidth=1.2, label='AdMD$_{\\Psi^{(\ell^2)}(\mathbf{w})}$ under log-cosh loss')
# ax.plot(indices, L2norm_ADMD_error_trials_mean_logcoshloss_b[indices], c='brown', linestyle='--', linewidth=1.2, label='AdMD$_{\\Psi^{(\ell^2)}(\mathbf{w})}$ under log-cosh loss')
ax.plot(indices, L2norm_ADMD_error_trials_mean_logloss_a[indices], c='royalblue', linestyle='--', linewidth=1.2, label='AdMD$_{\\Psi^{(\ell^2)}(\mathbf{w})}$ under log loss')
# ax.plot(indices, L2norm_ADMD_error_trials_mean_logloss_b[indices], c='royalblue', linestyle=':', linewidth=1.5, label='AdMD$_{\\Psi^{(\ell^2)}(\mathbf{w})}$ under log loss')

# plt.legend(ncol=4, loc='upper center', bbox_to_anchor=(0.5, -0.1), fontsize='13')
plt.yscale('log')
plt.xscale('log')
plt.ylim(-0.1, 300) # d= 3
plt.xlim(10, 100100) # d= 3

ax.legend(ncol=1, loc='upper right', fontsize='14')
plt.tight_layout()
plt.savefig(f'../AdMD_figures/Theorem4_error_Without_wstar_datasize{datasize}_dim{dim}_noise_var{noise_var}_T{T}_{trials}trials_setting{setting}_logcoshloss_and_logloss_a.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()


