import numpy as np
import math
from tomo_algorithm.tomo_Theorem3_no_wstar_noadjust_GPU_eta5 import main_function
import random
import time
time_start = time.time()
import scipy.io as sio
import random
from scipy.sparse import csr_matrix



algorithm_nums = 3
T = 8000
trials = 10
L2norm_ADMD_diff_w_trials = np.empty(shape=(trials, T))
KL_ADMD_diff_w_trials = np.empty(shape=(trials, T))
epsilon_ADMD_diff_w_trials = np.empty(shape=(trials, T))

L2norm_ADMD_error_trials = np.empty(shape=(trials, T))
KL_ADMD_error_trials = np.empty(shape=(trials, T))
epsilon_ADMD_error_trials = np.empty(shape=(trials, T))

L2norm_ADMD_sparse_trials = np.empty(shape=(trials, T))
KL_ADMD_sparse_trials = np.empty(shape=(trials, T))
epsilon_ADMD_sparse_trials = np.empty(shape=(trials, T))


epsilon_for_tune = 1e-8
epsilon_in_mirror = 1e-8
eta_ = 1 / 100
c1 = 0.3
beta1_design, beta2_design = 'beta1_2', 'beta2_2'

# 参数设定
N = 32
noise_std = 0.05  # 噪声的标准差
spa_theta = 1
p = N
R = 2



for j in range(trials):
    print(j)
    # 加载.mat文件
    fan_file = f'../data/fan_N{N}s{spa_theta}p{p}R{R}.mat'
    data = sio.loadmat(fan_file)
    A = csr_matrix(data['A'])  # 将 A 转换为稀疏矩阵格式
    X_train = A.toarray()
    y_free = data['y_free'].flatten()
    w_star = data['w_star'].flatten()
    # 对标签添加噪声
    np.random.seed(j + 10)
    noise = noise_std * np.random.randn(len(y_free))
    y_train = y_free + noise

    diff_w_set, error_set, n_sparse_set = main_function(X_train, y_train, X_train, y_free, T, w_star, epsilon_in_mirror, epsilon_for_tune, eta_, c1, beta1_design, beta2_design, algorithm_nums)

    L2norm_ADMD_diff_w_trials[j, :], L2norm_ADMD_error_trials[j, :], L2norm_ADMD_sparse_trials[j, :] = np.squeeze(np.array(diff_w_set[0])), np.squeeze(np.array(error_set[0])), np.squeeze(np.array(n_sparse_set[0]))
    KL_ADMD_diff_w_trials[j, :], KL_ADMD_error_trials[j, :], KL_ADMD_sparse_trials[j, :] = np.squeeze(np.array(diff_w_set[1])), np.squeeze(np.array(error_set[1])), np.squeeze(np.array(n_sparse_set[1]))
    epsilon_ADMD_diff_w_trials[j, :], epsilon_ADMD_error_trials[j, :], epsilon_ADMD_sparse_trials[j, :] = np.squeeze(np.array(diff_w_set[2])), np.squeeze(np.array(error_set[2])), np.squeeze(np.array(n_sparse_set[2]))


# ☀️save final
Runing_result = {
    'L2norm_ADMD_diff_w_trials': L2norm_ADMD_diff_w_trials,
    'L2norm_ADMD_error_trials': L2norm_ADMD_error_trials,
    'L2norm_ADMD_sparse_trials': L2norm_ADMD_sparse_trials,
    'KL_ADMD_diff_w_trials': KL_ADMD_diff_w_trials,
    'KL_ADMD_error_trials': KL_ADMD_error_trials,
    'KL_ADMD_sparse_trials': KL_ADMD_sparse_trials,
    'epsilon_ADMD_diff_w_trials': epsilon_ADMD_diff_w_trials,
    'epsilon_ADMD_error_trials': epsilon_ADMD_error_trials,
    'epsilon_ADMD_sparse_trials': epsilon_ADMD_sparse_trials}


theorem = '3'
filename = f'../tomo_result/Tomo_Theorem{theorem}_noise_var{noise_std}_T{T}_{trials}trials_eta5.npy'
np.save(filename, Runing_result)

print('------------------------------ runing information ------------------------------------------')
time_total = time.time() - time_start
print('running time:', time_total)
print(filename)
print(Runing_result.keys())

