import numpy as np
import math
import random
import os, time
from numpy import *
import matplotlib.pyplot as plt
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
config = {
    "font.family":'Times New Roman',
    "font.size": 15,
    "mathtext.fontset":'stix',
}
rcParams.update(config)


theorem = '4'
T = 8000
trials = 10

setting = 'a'
noise_std = 0.05
filename_load_a = f'../tomo_result/Tomo_Theorem{theorem}_noise_var{noise_std}_T{T}_{trials}trials_log_setting{setting}.npy'
AdMD_result_a = np.load(filename_load_a, allow_pickle=True).item()
L2norm_ADMD_diff_w_trials_mean_a = np.mean(AdMD_result_a['L2norm_ADMD_diff_w_trials'], axis=0)
L2norm_ADMD_error_trials_mean_a = np.mean(AdMD_result_a['L2norm_ADMD_error_trials'], axis=0)
L2norm_ADMD_sparse_trials_mean_a = np.mean(AdMD_result_a['L2norm_ADMD_sparse_trials'], axis=0)

setting = 'b'
filename_load_b = f'../tomo_result/Tomo_Theorem{theorem}_noise_var{noise_std}_T{T}_{trials}trials_log_setting{setting}.npy'
AdMD_result_b = np.load(filename_load_b, allow_pickle=True).item()
L2norm_ADMD_diff_w_trials_mean_b = np.mean(AdMD_result_b['L2norm_ADMD_diff_w_trials'], axis=0)
L2norm_ADMD_error_trials_mean_b = np.mean(AdMD_result_b['L2norm_ADMD_error_trials'], axis=0)
L2norm_ADMD_sparse_trials_mean_b = np.mean(AdMD_result_b['L2norm_ADMD_sparse_trials'], axis=0)


'''------------------------------  画图  ------------------------------'''
indices = [i for i in range(1, T+1, 1)]
num_points = 100
# 生成对数间隔的索引，保证索引在 1 到 T 之间
indices = np.unique(np.logspace(0, np.log10(T), num=num_points, dtype=int)) - 1
# 防止索引超出范围（因为有时候可能会有T以外的数）
indices = np.clip(indices, 0, T - 1)
print(indices)

fig = plt.figure(tight_layout=True)
fig = plt.figure(figsize=(6, 5), tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])


'''------------------- 1. error -------------------'''
ax.set_ylabel('Error (under log loss)', fontsize='15')
# ax.set_xlabel('Iterations \n (Uniformly sampling, $N=1000, d=100, \\sigma=0.05$)', fontsize='15')
# ax.set_xlabel('Iterations ($\\beta_{2,t}=1-t^{-2}$) \n (Normal distribution sampling, $N=1000, d=100, \\sigma=0.05$)', fontsize='15')
# ax.set_xlabel('Iterations \n($\\beta_{1,t}=1-T^{-1/2}, \\beta_{2,t}=1-T^{-1}, \\eta_t=T^{-1/2}, \\sigma=0.05$)',
#                fontsize='15')

ax.set_xlabel('Iterations',
               fontsize='15')

ax.plot(indices, L2norm_ADMD_error_trials_mean_a[indices], c='brown', linestyle='-', linewidth=1.2, label='AdMD$_{\\Psi^{(\ell^2)}(\mathbf{w})}$ (setting (a) with $\\eta_1=0.5$)')
ax.plot(indices, L2norm_ADMD_error_trials_mean_b[indices], c='royalblue', linestyle='-', linewidth=1.2, label='AdMD$_{\\Psi^{(\ell^2)}(\mathbf{w})}$ (setting (b) with $\\eta_1=0.05$)')

plt.yscale('log')
plt.xscale('log')
plt.ylim(-0.1, 101) # d= 3
plt.xlim(10, 10010) # d= 3

ax.legend(ncol=1, loc='lower left', fontsize='13')
plt.tight_layout()
plt.savefig(f'../tomo_figures/Theorem4_N11520_d1024_noise_var{noise_std}_T{T}_{trials}trials_log.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()


# print(X_train.shape)
# print(w_star.shape)
# (11520, 1024)
# (1024,)





'''------------------- 2. sparse -------------------'''
# # ax.set_ylabel('Sparsity (the number of coefficients larger than $10^{-8}$', fontsize='15')
# ax.set_ylabel('Sparsity', fontsize='15')
# ax.set_xlabel('Iterations \n($\\beta_{1,t}=c_1t^{-1/2}, \\beta_{2,t}=1-T^{-1}, \\eta=0.01, \\sigma=0.05$)',
#               fontsize='15')
#
# ax.plot(indices, L2norm_ADMD_sparse_trials_mean[indices], c='forestgreen', linestyle='-', linewidth=1.2, label='AdMD$_{\\Psi^{(\ell^2)}(\mathbf{w})}$')
# ax.plot(indices, KL_ADMD_sparse_trials_mean[indices], c='brown', linestyle='-', linewidth=1.2, label='AdMD$_{\\Psi^{(KL)}(\mathbf{w})}$')
# ax.plot(indices, epsilon_ADMD_sparse_trials_mean[indices], c='brown', linestyle='-', linewidth=1.2, label='AdMD$_{\\Psi^{(\\epsilon)}(\mathbf{w})}$')
#
#
# # ax.plot(indices, L2norm_MD_sparse_trials_mean[indices], c='orange', linestyle='--', linewidth=1.2, label='MD with $\\Psi^{(\ell^2)}(\mathbf{w})$ (SGD)')
# # ax.plot(indices, KL_MD_sparse_trials_mean[indices], c='brown', linestyle='--', linewidth=1.2, label='MD with $\\Psi^{(KL)}(\mathbf{w})$')
# # ax.plot(indices, epsilon_MD_sparse_trials_mean[indices], c='purple', linestyle='--', linewidth=1.2, label='MD with $\\Psi^{(\\epsilon)}(\mathbf{w})$')
#
# # ax.plot(indices, SGD_sparse_trials_mean[indices], c='royalblue', linestyle='-', linewidth=1.2, label='SGD ($\\eta_t=0.01$)') # = error_set[3][indices] MD L2norm
# # ax.plot(indices, AdaGrad_sparse_trials_mean[indices], c='blue', linestyle='-', linewidth=1.2, label='AdaGrad ($\\eta_t=0.5$)')
# # ax.plot(indices, Vanilla_sparse_trials_mean[indices], c='black', linestyle='-', linewidth=1.2, label='Vanilla Adam')  # =error_set[0][indices] AdMD, L2norm, 没有调整时
#
# # plt.legend(ncol=4, loc='upper center', bbox_to_anchor=(0.5, -0.1), fontsize='13')
# #
# # plt.yscale('log')
# plt.xscale('log')
# plt.ylim(0, 105)
#
# plt.xlim(10, 100100) # d= 3
# ax.legend(ncol=1, loc='upper left', fontsize='12')
# plt.tight_layout()
# plt.savefig(f'../AdMD_figures/Theorem1_2_sparse_With_wstar_datasize{datasize}_dim{dim}_noise_var{noise_var}_T{T}_eta{eta_}_beta1={beta1}_beta2={beta2}_c1{c1}_{trials}trials.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()