import numpy as np
import math
import random
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
import scipy.io as sio
import random
from scipy.sparse import csr_matrix

config = {
    "font.family": 'Times New Roman',
    "font.size": 17,
    "mathtext.fontset": 'stix',
}
rcParams.update(config)



def create_y(x, w_star):
    y = np.dot(x, w_star)
    return y


def sample(train_size, dim, noise_var, seed_i):
    np.random.seed(seed_i)
    w_star = np.random.randn(dim)
    # (1)
    X_train = np.random.randn(train_size, dim)
    y_free = np.random.randn(train_size)
    # (2)
    noise = noise_var * np.random.randn(len(y_free))
    y_train_free = y_free
    y_train = y_free + noise
    return X_train.shape, y_train.shape, X_train, y_train, y_train_free, w_star





# def sample(train_size, dim, noise_var, seed_i):
#     # 生成 w_star 并确保它的 L1 范数为 1
#     np.random.seed(seed_i)
#     w_star = np.random.randn(dim)
#     # w_star = np.maximum(w_star, 0)  # 确保权重为非负
#     # w_star = w_star / np.sum(w_star)  # 归一化，确保 L1 范数为 1
#
#     # 生成训练数据 X_train
#     X_train = np.random.randn(train_size, dim)
#
#     # 使用 w_star 生成 y_train_free
#     y_train_free = create_y(X_train, w_star)
#
#     # 添加噪声
#     noise = noise_var * np.random.randn(train_size)
#     y_train = y_train_free + noise
#
#     return X_train.shape, y_train.shape, X_train, y_train, y_train_free, w_star


def generate_data(train, dim, noise_var, seed_i):
    samples = sample(train, dim, noise_var, seed_i)
    X_train, y_train, y_train_free, w_star = samples[2], samples[3], samples[4], samples[5]
    # print('\n ########### ♣️From dim = %s | noise_var=%s | Train set X:%s, y:%s | Test set X:%s, y:%s  ##########' % (dim, noise_var, samples[0], samples[1]))
    return X_train, y_train, y_train_free, w_star


''' -----------------------   2. 不同的mirror map，求偏导数，反解系数w ----------------------- '''
# --------------------- 求偏导数 ---------------------
def Grad_of_mirror_epsilon(w, epsilon_):
    grad_of_mirror = np.copy(w)
    idx_1 = np.abs(w) <= epsilon_
    idx_2 = ~idx_1
    grad_of_mirror[idx_1] = grad_of_mirror[idx_1] / epsilon_
    grad_of_mirror[idx_2] = np.sign(grad_of_mirror[idx_2])
    grad_of_mirror = grad_of_mirror + w
    return grad_of_mirror


def Grad_of_mirror_KL(w):
    # 修正：需要保证w向量中的每一个元素都是正数，并且加和为1，否则我没有办法计算np.log，也不满足KL 作为mirror map的要求
    w[w <= 0] = 1e-8
    # print(w)
    # print(w.shape)
    grad_of_mirror = 1 + np.log(w)
    return grad_of_mirror


# --------------------- 反解系数w  ---------------------
def w_from_grad_of_mirror_epsilon(grad_t, epsilon_):  # 从每次的梯度中反解出系数w
    w_from_grad = np.copy(grad_t).astype(float)
    lambda_ = 1  # 论文中没有引入多余的这个参数
    value1 = lambda_ + epsilon_
    value2 = epsilon_ / value1
    idx_1 = np.abs(grad_t) <= value1
    idx_2 = ~idx_1
    w_from_grad[idx_1] = grad_t[idx_1] * value2
    w_from_grad[idx_2] = (np.abs(grad_t[idx_2]) - lambda_) * np.sign(grad_t[idx_2])
    return w_from_grad


def w_from_grad_of_mirror_KL(grad_t):
    w_from_grad = np.exp(grad_t - 1)
    return w_from_grad


def project_to_l1_ball(w):
    """将 w 投影到 L1 范数为 1 的非负权重空间"""
    if np.sum(w) == 1 and np.all(w >= 0):
        return w  # 已经满足条件，不需要投影

    # 1. 对权重进行降序排序
    u = np.sort(w)[::-1]
    sv = np.cumsum(u)  # 计算累计和

    # 2. 计算 rho
    condition = u * np.arange(1, len(w) + 1) > (sv - 1)
    rho_indices = np.nonzero(condition)[0]
    # print(rho_indices)

    # 3. 如果没有满足条件的 rho，默认处理：直接归一化，确保权重满足 L1 范数为 1
    if len(rho_indices) == 0:
        print("Warning: No valid rho found, applying normalization as fallback.")
        return w / np.sum(w)  # 简单归一化作为备选方案

    # 4. 正常情况下找到 rho
    rho = rho_indices[-1]
    # 5. 计算 theta
    theta = (sv[rho] - 1) / (rho + 1.0)
    # 6. 执行投影
    w_proj = np.maximum(w - theta, 0)
    return w_proj


'''
方式一：确保每次迭代时权重大于 0（自适应调整机制的优势）
方式二：制造最优权重的 l1-范数为 1 的数据（处理概率分布的优势）
    w_new = np.maximum(w_new, 0)  # 确保 w 非负
    w_new = w_new / np.sum(w_new)  # 保证 L1 范数为 1             (2)直接归一化法；KL的结果直接变平变好，可能是因为wi被人为调整迅速的变好
    所有的算法都要进行这个操作
'''
def kl_divergence_update(w, grad):
    w_new = w * np.exp(-grad)
    w_new = np.maximum(w_new, 0)  # 确保 w 非负
    # w_new = project_to_l1_ball(w_new)  # 投影到 L1 范数为 1     (1) duchi 投影算法
    # w_new = w_new / np.sum(w_new)  # 保证 L1 范数为 1             (2)直接归一化法；KL的结果直接变平变好，可能是因为wi被人为调整迅速的变好
    return w_new



''' -----------------------   3. 不同算法对系数的更新方式 ----------------------- '''
# ⚠️m_current, v_current 需要赋予初始值
def mirror_descent_part_calculation(w_current, m_current, v_current, x_iter, y_iter, t_iter, T, eta_, eps_, beta1, beta2):
    # eta_ = 1 / math.sqrt(t_iter)
    # eta_ = 1 / 100
    # eps_ = 1e-8
    # c1 = 0.3  # \in (0, 1)
    # beta1 = c1 * (1 / math.sqrt(t_iter))
    # beta2 = 1 - 1 / T
    # g = (np.dot(x_iter, w_current) - y_iter) * x_iter
    lambda1 = 0.9
    g = (np.dot(x_iter, w_current) - y_iter) * x_iter + lambda1 * w_current
    m_update = beta1 * m_current + (1 - beta1) * g
    v_update = beta2 * v_current + (1 - beta2) * g ** 2
    vv = np.sqrt(v_update) + eps_
    mirror_descent_part = eta_ * m_update / vv
    return mirror_descent_part, m_update, v_update


def SGD_update(w_current, x_iter, y_iter, t_iter, eta_):  # 在第t迭代时的系数的更新
    # eta_ = 1 / 100
    # eta_ = 1 / math.sqrt(t_iter)
    # g = np.squeeze((np.dot(x_iter, w_current) - y_iter) * x_iter * eta_)
    lambda1 = 0.9
    g = ((np.dot(x_iter, w_current) - y_iter) * x_iter + lambda1 * w_current) * eta_
    g = np.squeeze(g)
    w_update = w_current - g
    # w_update = np.maximum(w_update, 0)  # 确保 w 非负
    # w_update = w_update / np.sum(w_update)  # 保证 L1 范数为 1
    return w_update


def MD_update(w_current, epsilon_, x_iter, y_iter, t_iter, T, eta_, map_func):
    # （1）求mirror_descent_part, 这部分和SGD的右侧一样
    # eta_ = 1/math.sqrt(t_iter)
    # eta_ = 1 / 100
    # mirror_descent_part = (np.dot(x_iter, w_current) - y_iter) * x_iter * eta_
    lambda1 = 0.9
    mirror_descent_part = ((np.dot(x_iter, w_current) - y_iter) * x_iter + lambda1 * w_current) * eta_

    # （2）求关于mirror map的导数
    if map_func == 'mirror_epsilon':
        grad_mirror = Grad_of_mirror_epsilon(w_current, epsilon_)
        grad_mirror_new = grad_mirror - mirror_descent_part
    if map_func == 'mirror_L2norm':  # 也就是Adam
        grad_mirror = w_current
        grad_mirror_new = grad_mirror - mirror_descent_part

    # （4）反解出系数w
    if map_func == 'mirror_epsilon':
        w_update = w_from_grad_of_mirror_epsilon(grad_mirror_new, epsilon_)
    if map_func == 'mirror_KL':
        # w_update = w_from_grad_of_mirror_KL(grad_mirror_new)
        w_update = kl_divergence_update(w_current, mirror_descent_part)
    if map_func == 'mirror_L2norm':
        w_update = grad_mirror_new

    # w_update = np.maximum(w_update, 0)  # 确保 w 非负
    # w_update = w_update / np.sum(w_update)  # 保证 L1 范数为 1
    w_update = np.squeeze(w_update)
    return w_update



def AdMD_update(w_current, m_current, v_current, epsilon_, x_iter, y_iter, t_iter, T, eta_, eps_, beta1, beta2, map_func):
    # （1）求m,v的部分，统称为mirror_descent_part
    mirror_descent_part, m_update, v_update = mirror_descent_part_calculation(w_current, m_current, v_current, x_iter,
                                                                              y_iter, t_iter, T, eta_, eps_, beta1, beta2)
    # （2）求关于mirror map的导数
    if map_func == 'mirror_epsilon':
        grad_mirror = Grad_of_mirror_epsilon(w_current, epsilon_)
        grad_mirror_new = grad_mirror - mirror_descent_part
    if map_func == 'mirror_L2norm':  # 也就是Adam
        grad_mirror = w_current
        grad_mirror_new = grad_mirror - mirror_descent_part

    # （4）反解出系数w
    if map_func == 'mirror_epsilon':
        w_update = w_from_grad_of_mirror_epsilon(grad_mirror_new, epsilon_)
    if map_func == 'mirror_KL':
        # w_update = w_from_grad_of_mirror_KL(grad_mirror_new)
        w_update = kl_divergence_update(w_current, mirror_descent_part)

    if map_func == 'mirror_L2norm':
        w_update = grad_mirror_new

    # w_update = np.maximum(w_update, 0)  # 确保 w 非负
    # w_update = w_update / np.sum(w_update)  # 保证 L1 范数为 1
    w_update = np.squeeze(w_update)
    return w_update, m_update, v_update


def AdaGrad_descent_part_calculation(w_current, v_current, x_iter, y_iter, T, t_iter, eta_, eps_):
    # eta_ = 1 / math.sqrt(t_iter) # 这个结果也会稍微好一些
    # eta_ = 1 / 100 # 这个结果很差，是因为，vt=g^2所造成的步伐会很小，而我们的AdMD的步伐只是0.0001* g^2,也就是步伐很大，所以我们调大步伐，不妨假设步伐为1/T
    # eta_ = 0.5  # 我们要么把eta变大，要么给AdaGrad的Vt加一个系数，但是为了不损失它的定义，我们决定改变eta
    # eps_ = 1e-8
    # g = (np.dot(x_iter, w_current) - y_iter) * x_iter
    lambda1 = 0.9
    g = (np.dot(x_iter, w_current) - y_iter) * x_iter + lambda1 * w_current


    m_update = g
    v_update = v_current + g ** 2  # g**2 的加和
    vv = np.sqrt(v_update) + eps_
    mirror_descent_part = eta_ * m_update / vv
    return mirror_descent_part, v_update


def AdaGrad_update(w_current, v_current, x_iter, y_iter, T, t_iter, eta_, epsilon_for_tune):
    mirror_descent_part, v_update = AdaGrad_descent_part_calculation(w_current, v_current, x_iter, y_iter, T, t_iter, eta_, epsilon_for_tune)
    w_update = w_current - mirror_descent_part
    # w_update = np.maximum(w_update, 0)  # 确保 w 非负
    # w_update = w_update / np.sum(w_update)  # 保证 L1 范数为 1
    w_update = np.squeeze(w_update)
    return w_update, v_update



def mirror_descent_part_calculation_for_vanilla(w_current, m_current, v_current, x_iter, y_iter, t_iter, T, eta_, eps_, beta1, beta2):
    # eta_ = 1 / 100
    # eps_ = 1e-8
    # c1 = 0.3  # \in (0, 1)
    # beta1 = c1 * (1 / math.sqrt(t_iter))
    # beta2 = 1 - 1 / T
    g = (np.dot(x_iter, w_current) - y_iter) * x_iter

    m_update = beta1 * m_current + (1 - beta1) * g
    v_update = beta2 * v_current + (1 - beta2) * g ** 2

    # 偏差纠正
    # m_update = m_update / (1-beta1**t_iter)
    # v_update = v_update / (1-beta2**t_iter)
    # print(t_iter)
    # print(1-beta2**t_iter)

    vv = np.sqrt(v_update) + eps_
    mirror_descent_part = eta_ * m_update / vv
    return mirror_descent_part, m_update, v_update




def vanilla_AdMD_update(w_current, m_current, v_current, x_iter, y_iter, t_iter, T, eta_, eps_, beta1, beta2):
    mirror_descent_part, m_update, v_update = mirror_descent_part_calculation_for_vanilla(w_current, m_current, v_current, x_iter, y_iter, t_iter, T, eta_, eps_, beta1, beta2)
    w_update = w_current - mirror_descent_part

    # w_update = np.maximum(w_update, 0)  # 确保 w 非负
    # w_update = w_update / np.sum(w_update)  # 保证 L1 范数为 1
    w_update = np.squeeze(w_update)
    # print('w_update.shape', w_update.shape)
    return w_update, m_update, v_update



print('theorem 3')
def main_function(x, y, x_for_test, y_for_test, T, w_star, epsilon_in_mirror, epsilon_for_tune, eta_, c1, beta1_design, beta2_design, algorithm_nums):

    x_size, x_dim = x.shape[0], x.shape[1],
    w_current = np.random.rand(x_dim) # 生成一个或多个在 [0,1) 区间均匀分布的随机数
    # w_current /= np.sum(w_current)  # 归一化，使 L1 范数为

    w_current_SGD, w_current_L2norm_AdMD, w_current_KL_AdMD, w_current_epsilon_AdMD, w_current_vanilla_adam = w_current, w_current, w_current, w_current, w_current
    w_current_L2norm_MD, w_current_KL_MD, w_current_epsilon_MD, w_current_AdaGrad = w_current, w_current, w_current, w_current
    m_current_L2norm, v_current_L2norm, m_current_KL, v_current_KL, m_current_epsilon, v_current_epsilon, m_current_vanilla_adam, v_current_vanilla_adam = np.zeros(
        x_dim), np.zeros(x_dim), np.zeros(x_dim), np.zeros(x_dim), np.zeros(x_dim), np.zeros(x_dim), np.zeros(x_dim), np.zeros(x_dim)
    v_current_AdaGrad = np.zeros(x_dim)

    # 用来存放每一次迭代后的结果
    diff_w_set = np.zeros((algorithm_nums, T))
    error_set = np.zeros((algorithm_nums, T))
    n_sparse_set = np.zeros((algorithm_nums, T))
    norm_star = np.linalg.norm(w_star)
    print('---new')
    for i in range(1, T + 1):
        # print('---new')
        t_iter = i
        if beta1_design == 'beta1_1' and beta2_design == 'beta2_1':
            # print('beta1_1, beta1_1')
            beta1 = c1 / t_iter
            beta2 = 1 - 1 / T

        if beta1_design == 'beta1_2' and beta2_design == 'beta2_2':
            # print('beta1_2, beta2_2')
            beta1 = c1 / t_iter
            beta2 = 1 - t_iter ** (-2)

        np.random.seed(t_iter)
        idx = np.random.randint(x_size, size=1)  # 每次随机选取的样本
        x_iter = x[idx]
        y_iter = y[idx]
        eta_ = 0.05 / t_iter

        w_current_L2norm_AdMD, m_current_L2norm, v_current_L2norm = AdMD_update(w_current_L2norm_AdMD, m_current_L2norm, v_current_L2norm, epsilon_in_mirror, x_iter, y_iter, t_iter, T, eta_, epsilon_for_tune, beta1, beta2, map_func='mirror_L2norm')
        w_current_KL_AdMD, m_current_KL, v_current_KL = AdMD_update(w_current_KL_AdMD, m_current_KL, v_current_KL, epsilon_in_mirror, x_iter, y_iter, t_iter, T, eta_, epsilon_for_tune, beta1, beta2, map_func='mirror_KL')
        w_current_epsilon_AdMD, m_current_epsilon, v_current_epsilon = AdMD_update(w_current_epsilon_AdMD, m_current_epsilon, v_current_epsilon, epsilon_in_mirror, x_iter, y_iter, t_iter, T, eta_, epsilon_for_tune, beta1, beta2, map_func='mirror_epsilon')

        # （1） 记录系数的差别
        diff_w_MdMD_L2norm = w_current_L2norm_AdMD - w_star
        diff_w_MdMD_KL = w_current_KL_AdMD - w_star
        diff_w_MdMD_epsilon = w_current_epsilon_AdMD - w_star

        diff_w_set[0, i - 1] = np.linalg.norm(diff_w_MdMD_L2norm) / norm_star
        diff_w_set[1, i - 1] = np.linalg.norm(diff_w_MdMD_KL) / norm_star
        diff_w_set[2, i - 1] = np.linalg.norm(diff_w_MdMD_epsilon) / norm_star

        # （2） 记录迭代后的系数在无噪音的训练数据伤的误差
        # 在无噪音的训练数据上测试误差时，输入的x_for_test, y_for_test是：x, y_train_f
        # 在测试数据上测试误差时，输入的x_for_test, y_for_test是：x_test, y_test
        error_set[0, i - 1] = np.sum((np.dot(x_for_test, w_current_L2norm_AdMD) - y_for_test) ** 2) / x_for_test.shape[0]
        error_set[1, i - 1] = np.sum((np.dot(x_for_test, w_current_KL_AdMD) - y_for_test) ** 2) / x_for_test.shape[0]
        error_set[2, i - 1] = np.sum((np.dot(x_for_test, w_current_epsilon_AdMD) - y_for_test) ** 2) / x_for_test.shape[0]

        # （3） 记录每一次迭代后的系数的非零元素的个数
        n_sparse_set[0, i - 1] = np.sum(np.abs(w_current_L2norm_MD) > 1e-8)
        n_sparse_set[1, i - 1] = np.sum(np.abs(w_current_KL_MD) > 1e-8)
        n_sparse_set[2, i - 1] = np.sum(np.abs(w_current_epsilon_MD) > 1e-8)


    print(diff_w_set.shape)
    print(error_set.shape)
    print(n_sparse_set.shape)
    return diff_w_set, error_set, n_sparse_set




# -----------------------------（2）✅-----------------------------
# 参数设定
N = 32
noise_std = 0.05  # 噪声的标准差
lambda_ = 1  # 参数 lambda

# 创建数据
spa_theta = 1
p = N
R = 2

# 加载.mat文件
fan_file = f'../data/fan_N{N}s{spa_theta}p{p}R{R}.mat'
data = sio.loadmat(fan_file)
A = csr_matrix(data['A'])  # 将 A 转换为稀疏矩阵格式
A_dense = A.toarray()
y_free = data['y_free'].flatten()
w_star = data['w_star'].flatten()
X_train = A_dense
epsilon_for_tune = 1e-8
epsilon_in_mirror = 1e-8
eta_ = 0.1 / 100
c1 = 0.9  # \in (0, 1)
# beta1_design, beta2_design = 'beta1_1', 'beta2_1'
beta1_design, beta2_design = 'beta1_2', 'beta2_2'
# T = 100010
T = 8000
algorithm_nums = 3
trials = 10

# np.random.seed(17)
# # 对标签添加噪声
# noise = noise_std * np.random.randn(len(y_free))
# yy = y_free + noise
# y_train = yy
#
# diff_w_set, error_set, n_sparse_set = main_function(X_train, y_train, X_train, y_free, T, w_star, epsilon_in_mirror,
#                                                     epsilon_for_tune, eta_, c1, beta1_design, beta2_design,
#                                                     algorithm_nums)
#
# # # '''------------------------------  画图  ------------------------------'''
# T_list = [i for i in range(1, T + 1, 1)]
# num_points = 100
# # 生成对数间隔的索引，保证索引在 1 到 T 之间
# indices = np.unique(np.logspace(0, np.log10(T), num=num_points, dtype=int)) - 1
# # 防止索引超出范围（因为有时候可能会有T以外的数）
# indices = np.clip(indices, 0, T - 1)
# fig = plt.figure(tight_layout=True)
# fig = plt.figure(figsize=(6, 5), tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.set_ylabel('Error', fontsize='15')
# ax.set_xlabel('Iterations ($\\beta_{2,t}=1-t^{-2}$) \n ($N=5760, d=16\\times16, \\sigma=0.05$)',
#               fontsize='15')
# ax.plot(T_list, error_set[0], c='green', linestyle='-', linewidth=1.2, label='AdMD with $\\Psi^{(\ell^2)}(\mathbf{w})$')
# ax.plot(T_list, error_set[1], c='orange', linestyle='-', linewidth=1.2, label='AdMD with $\\Psi^{(KL)}(\mathbf{w})$')
# ax.plot(T_list, error_set[2], c='purple', linestyle='-', linewidth=1.2,
#         label='AdMD with $\\Psi^{(\\epsilon)}(\mathbf{w})$')
# plt.yscale('log')
# plt.xscale('log')
# # plt.ylim(0, 50) # d= 3
# ax.legend(ncol=1, loc='lower left', fontsize='12')
# plt.savefig(f'../tomo_figures/test/random.pdf', dpi=600, format='pdf', bbox_inches='tight',
#             pad_inches=0.2)
# plt.show()
#




L2norm_ADMD_diff_w_trials = np.empty(shape=(trials, T))
KL_ADMD_diff_w_trials = np.empty(shape=(trials, T))
epsilon_ADMD_diff_w_trials = np.empty(shape=(trials, T))

L2norm_ADMD_error_trials = np.empty(shape=(trials, T))
KL_ADMD_error_trials = np.empty(shape=(trials, T))
epsilon_ADMD_error_trials = np.empty(shape=(trials, T))

L2norm_ADMD_sparse_trials = np.empty(shape=(trials, T))
KL_ADMD_sparse_trials = np.empty(shape=(trials, T))
epsilon_ADMD_sparse_trials = np.empty(shape=(trials, T))



for j in range(10):
    np.random.seed(j+10)
    # 对标签添加噪声
    noise = noise_std * np.random.randn(len(y_free))
    yy = y_free + noise
    y_train = yy

    diff_w_set, error_set, n_sparse_set = main_function(X_train, y_train, X_train, y_free, T, w_star, epsilon_in_mirror, epsilon_for_tune, eta_, c1, beta1_design, beta2_design, algorithm_nums)

    # # '''------------------------------  画图  ------------------------------'''
    T_list = [i for i in range(1, T+1, 1)]
    num_points = 100
    # 生成对数间隔的索引，保证索引在 1 到 T 之间
    indices = np.unique(np.logspace(0, np.log10(T), num=num_points, dtype=int)) - 1
    # 防止索引超出范围（因为有时候可能会有T以外的数）
    indices = np.clip(indices, 0, T - 1)
    fig = plt.figure(tight_layout=True)
    fig = plt.figure(figsize=(6, 5), tight_layout=True)
    gs = gridspec.GridSpec(1, 1)
    ax = fig.add_subplot(gs[0, 0])
    ax.set_ylabel('Error', fontsize='15')
    ax.set_xlabel('Iterations ($\\beta_{2,t}=1-t^{-2}$) \n ($N=5760, d=16\\times16, \\sigma=0.05$)',
                  fontsize='15')
    ax.plot(T_list, error_set[0], c='green', linestyle='-', linewidth=1.2, label='AdMD with $\\Psi^{(\ell^2)}(\mathbf{w})$')
    # ax.plot(T_list, error_set[1], c='orange', linestyle='-', linewidth=1.2, label='AdMD with $\\Psi^{(KL)}(\mathbf{w})$')
    ax.plot(T_list, error_set[2], c='purple', linestyle='-', linewidth=1.2, label='AdMD with $\\Psi^{(\\epsilon)}(\mathbf{w})$')
    plt.yscale('log')
    plt.xscale('log')
    # plt.ylim(0, 50) # d= 3
    ax.legend(ncol=1, loc='lower left', fontsize='12')
    plt.savefig(f'../tomo_figures/test/random_{j}.pdf', dpi=600, format='pdf', bbox_inches='tight',
                pad_inches=0.2)
    plt.show()

    L2norm_ADMD_diff_w_trials[j, :], L2norm_ADMD_error_trials[j, :], L2norm_ADMD_sparse_trials[j, :] = np.squeeze(np.array(diff_w_set[0])), np.squeeze(np.array(error_set[0])), np.squeeze(np.array(n_sparse_set[0]))
    KL_ADMD_diff_w_trials[j, :], KL_ADMD_error_trials[j, :], KL_ADMD_sparse_trials[j, :] = np.squeeze(np.array(diff_w_set[1])), np.squeeze(np.array(error_set[1])), np.squeeze(np.array(n_sparse_set[1]))
    epsilon_ADMD_diff_w_trials[j, :], epsilon_ADMD_error_trials[j, :], epsilon_ADMD_sparse_trials[j, :] = np.squeeze(np.array(diff_w_set[2])), np.squeeze(np.array(error_set[2])), np.squeeze(np.array(n_sparse_set[2]))

# ☀️save final
Runing_result = {
    'L2norm_ADMD_diff_w_trials': L2norm_ADMD_diff_w_trials,
    'L2norm_ADMD_error_trials': L2norm_ADMD_error_trials,
    'L2norm_ADMD_sparse_trials': L2norm_ADMD_sparse_trials,
    'KL_ADMD_diff_w_trials': KL_ADMD_diff_w_trials,
    'KL_ADMD_error_trials': KL_ADMD_error_trials,
    'KL_ADMD_sparse_trials': KL_ADMD_sparse_trials,
    'epsilon_ADMD_diff_w_trials': epsilon_ADMD_diff_w_trials,
    'epsilon_ADMD_error_trials': epsilon_ADMD_error_trials,
    'epsilon_ADMD_sparse_trials': epsilon_ADMD_sparse_trials}


theorem = '3'
filename = f'../tomo_result/Tomo_Theorem{theorem}_noise_var{noise_std}_T{T}_{trials}trials_new_32.npy'
np.save(filename, Runing_result)
print('------------------------------ runing information ------------------------------------------')
print(filename)
print(Runing_result.keys())



