import numpy as np
import math
import random
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
import scipy.io as sio
import random
from scipy.sparse import csr_matrix

config = {
    "font.family": 'Times New Roman',
    "font.size": 17,
    "mathtext.fontset": 'stix',
}
rcParams.update(config)



# 参数设定
N = 32
noise_std = 0.05 # 噪声的标准差
spa_theta = 1
p = N
R = 2

# 加载.mat文件
fan_file = f'../data/fan_N{N}s{spa_theta}p{p}R{R}.mat'
data = sio.loadmat(fan_file)
A = csr_matrix(data['A'])  # 将 A 转换为稀疏矩阵格式
X_train = A.toarray()
y_free = data['y_free'].flatten()
w_star = data['w_star'].flatten()



w = np.reshape(w_star, (N, N))
plt.imshow(w, cmap='gray')
plt.colorbar()
plt.xlabel('Ground truth of $\\mathbf{w}$',
              fontsize='15')
plt.savefig(f'../tomo_figures/weight_image_ori.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()
