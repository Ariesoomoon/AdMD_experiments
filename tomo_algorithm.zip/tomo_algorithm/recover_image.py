import numpy as np
import math
import random
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from matplotlib import rcParams
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
import scipy.io as sio
import random
from scipy.sparse import csr_matrix

config = {
    "font.family": 'Times New Roman',
    "font.size": 17,
    "mathtext.fontset": 'stix',
}
rcParams.update(config)




''' -----------------------   2. 不同的mirror map，求偏导数，反解系数w ----------------------- '''
# --------------------- 求偏导数 ---------------------
def Grad_of_mirror_epsilon(w, epsilon_):
    grad_of_mirror = np.copy(w)
    idx_1 = np.abs(w) <= epsilon_
    idx_2 = ~idx_1
    grad_of_mirror[idx_1] = grad_of_mirror[idx_1] / epsilon_
    grad_of_mirror[idx_2] = np.sign(grad_of_mirror[idx_2])
    grad_of_mirror = grad_of_mirror + w
    return grad_of_mirror


def Grad_of_mirror_KL(w):
    # 修正：需要保证w向量中的每一个元素都是正数，并且加和为1，否则我没有办法计算np.log，也不满足KL 作为mirror map的要求
    w[w <= 0] = 1e-8
    # print(w)
    # print(w.shape)
    grad_of_mirror = 1 + np.log(w)
    return grad_of_mirror


# --------------------- 反解系数w  ---------------------
def w_from_grad_of_mirror_epsilon(grad_t, epsilon_):  # 从每次的梯度中反解出系数w
    w_from_grad = np.copy(grad_t).astype(float)
    lambda_ = 1  # 论文中没有引入多余的这个参数
    value1 = lambda_ + epsilon_
    value2 = epsilon_ / value1
    idx_1 = np.abs(grad_t) <= value1
    idx_2 = ~idx_1
    w_from_grad[idx_1] = grad_t[idx_1] * value2
    w_from_grad[idx_2] = (np.abs(grad_t[idx_2]) - lambda_) * np.sign(grad_t[idx_2])
    return w_from_grad


def w_from_grad_of_mirror_KL(grad_t):
    w_from_grad = np.exp(grad_t - 1)
    return w_from_grad


def kl_divergence_update(w, grad):
    w_new = w * np.exp(-grad)
    w_new = np.maximum(w_new, 0)  # 确保 w 非负
    # w_new = project_to_l1_ball(w_new)  # 投影到 L1 范数为 1     (1) duchi 投影算法
    # w_new = w_new / np.sum(w_new)  # 保证 L1 范数为 1             (2)直接归一化法；KL的结果直接变平变好，可能是因为wi被人为调整迅速的变好
    return w_new



''' -----------------------   3. 不同算法对系数的更新方式 ----------------------- '''
# ⚠️m_current, v_current 需要赋予初始值
def mirror_descent_part_calculation(w_current, m_current, v_current, x_iter, y_iter, t_iter, T, eta_, eps_, beta1, beta2):
    # eta_ = 1 / math.sqrt(t_iter)
    # eta_ = 1 / 100
    # eps_ = 1e-8
    # c1 = 0.3  # \in (0, 1)
    # beta1 = c1 * (1 / math.sqrt(t_iter))
    # beta2 = 1 - 1 / T
    g = (np.dot(x_iter, w_current) - y_iter) * x_iter
    m_update = beta1 * m_current + (1 - beta1) * g
    v_update = beta2 * v_current + (1 - beta2) * g ** 2
    vv = np.sqrt(v_update) + eps_
    mirror_descent_part = eta_ * m_update / vv
    return mirror_descent_part, m_update, v_update



def AdMD_update(w_current, m_current, v_current, epsilon_, x_iter, y_iter, t_iter, T, eta_, eps_, beta1, beta2, map_func):
    # （1）求m,v的部分，统称为mirror_descent_part
    mirror_descent_part, m_update, v_update = mirror_descent_part_calculation(w_current, m_current, v_current, x_iter,
                                                                              y_iter, t_iter, T, eta_, eps_, beta1, beta2)
    # （2）求关于mirror map的导数
    if map_func == 'mirror_epsilon':
        grad_mirror = Grad_of_mirror_epsilon(w_current, epsilon_)
        grad_mirror_new = grad_mirror - mirror_descent_part
    if map_func == 'mirror_L2norm':  # 也就是Adam
        grad_mirror = w_current
        grad_mirror_new = grad_mirror - mirror_descent_part

    # （4）反解出系数w
    if map_func == 'mirror_epsilon':
        w_update = w_from_grad_of_mirror_epsilon(grad_mirror_new, epsilon_)
    if map_func == 'mirror_KL':
        # w_update = w_from_grad_of_mirror_KL(grad_mirror_new)
        w_update = kl_divergence_update(w_current, mirror_descent_part)

    if map_func == 'mirror_L2norm':
        w_update = grad_mirror_new

    # w_update = np.maximum(w_update, 0)  # 确保 w 非负
    # w_update = w_update / np.sum(w_update)  # 保证 L1 范数为 1
    w_update = np.squeeze(w_update)
    return w_update, m_update, v_update


print('theorem 2')
def main_function(x, y, x_for_test, y_for_test, T, w_star, epsilon_in_mirror, epsilon_for_tune, eta_, c1, beta1_design, beta2_design, algorithm_nums):

    x_size, x_dim = x.shape[0], x.shape[1]
    # w_current = np.random.randn(x_dim)  # 生成一个或多个在 [0,1) 区间均匀分布的随机数
    w_current = np.random.rand(x_dim) # 生成一个或多个在 [0,1) 区间均匀分布的随机数
    # w_current /= np.sum(w_current)  # 归一化，使 L1 范数为

    w_current_SGD, w_current_L2norm_AdMD, w_current_KL_AdMD, w_current_epsilon_AdMD, w_current_vanilla_adam = w_current, w_current, w_current, w_current, w_current
    w_current_L2norm_MD, w_current_KL_MD, w_current_epsilon_MD, w_current_AdaGrad = w_current, w_current, w_current, w_current
    m_current_L2norm, v_current_L2norm, m_current_KL, v_current_KL, m_current_epsilon, v_current_epsilon, m_current_vanilla_adam, v_current_vanilla_adam = np.zeros(
        x_dim), np.zeros(x_dim), np.zeros(x_dim), np.zeros(x_dim), np.zeros(x_dim), np.zeros(x_dim), np.zeros(x_dim), np.zeros(x_dim)
    v_current_AdaGrad = np.zeros(x_dim)

    # 用来存放每一次迭代后的结果
    diff_w_set = np.zeros((algorithm_nums, T))
    error_set = np.zeros((algorithm_nums, T))
    n_sparse_set = np.zeros((algorithm_nums, T))
    norm_star = np.linalg.norm(w_star)


    for i in range(1, T + 1):
        t_iter = i
        if beta1_design == 'beta1_1' and beta2_design == 'beta2_1':
            # print('beta1_1, beta1_1')
            beta1 = c1 * (1 / math.sqrt(t_iter))
            beta2 = 1 - 1 / T

        if beta1_design == 'beta1_2' and beta2_design == 'beta2_2':
            # print('beta1_2, beta2_2')
            beta1 = c1 * (1 / math.sqrt(t_iter))
            beta2 = 1 - t_iter ** (-2)

        np.random.seed(t_iter)
        idx = np.random.randint(x_size, size=1)  # 每次随机选取的样本
        x_iter = x[idx]
        y_iter = y[idx]
        eta_ = 0.04 / math.sqrt(t_iter)

        w_current_L2norm_AdMD, m_current_L2norm, v_current_L2norm = AdMD_update(w_current_L2norm_AdMD, m_current_L2norm, v_current_L2norm, epsilon_in_mirror, x_iter, y_iter, t_iter, T, eta_, epsilon_for_tune, beta1, beta2, map_func='mirror_L2norm')
        w_current_KL_AdMD, m_current_KL, v_current_KL = AdMD_update(w_current_KL_AdMD, m_current_KL, v_current_KL, epsilon_in_mirror, x_iter, y_iter, t_iter, T, eta_, epsilon_for_tune, beta1, beta2, map_func='mirror_KL')
        w_current_epsilon_AdMD, m_current_epsilon, v_current_epsilon = AdMD_update(w_current_epsilon_AdMD, m_current_epsilon, v_current_epsilon, epsilon_in_mirror, x_iter, y_iter, t_iter, T, eta_, epsilon_for_tune, beta1, beta2, map_func='mirror_epsilon')


        # （1） 记录系数的差别
        diff_w_MdMD_L2norm = w_current_L2norm_AdMD - w_star
        diff_w_MdMD_KL = w_current_KL_AdMD - w_star
        diff_w_MdMD_epsilon = w_current_epsilon_AdMD - w_star



        diff_w_set[0, i - 1] = np.linalg.norm(diff_w_MdMD_L2norm) / norm_star
        diff_w_set[1, i - 1] = np.linalg.norm(diff_w_MdMD_KL) / norm_star
        diff_w_set[2, i - 1] = np.linalg.norm(diff_w_MdMD_epsilon) / norm_star


        # （2） 记录迭代后的系数在无噪音的训练数据伤的误差
        # 在无噪音的训练数据上测试误差时，输入的x_for_test, y_for_test是：x, y_train_f
        # 在测试数据上测试误差时，输入的x_for_test, y_for_test是：x_test, y_test
        error_set[0, i - 1] = np.sum((np.dot(x_for_test, w_current_L2norm_AdMD) - y_for_test) ** 2) / x_for_test.shape[0]
        error_set[1, i - 1] = np.sum((np.dot(x_for_test, w_current_KL_AdMD) - y_for_test) ** 2) / x_for_test.shape[0]
        error_set[2, i - 1] = np.sum((np.dot(x_for_test, w_current_epsilon_AdMD) - y_for_test) ** 2) / x_for_test.shape[0]



        # （3） 记录每一次迭代后的系数的非零元素的个数
        n_sparse_set[0, i - 1] = np.sum(np.abs(w_current_L2norm_MD) > 1e-8)
        n_sparse_set[1, i - 1] = np.sum(np.abs(w_current_KL_MD) > 1e-8)
        n_sparse_set[2, i - 1] = np.sum(np.abs(w_current_epsilon_MD) > 1e-8)

        # print('sparse of w_star', np.sum(np.abs(w_star) > 1e-8))

    print(diff_w_set.shape)
    print(error_set.shape)
    print(n_sparse_set.shape)
    return diff_w_set, error_set, n_sparse_set, w_current_epsilon_AdMD, w_current_L2norm_AdMD



# -----------------------------（2）✅-----------------------------
epsilon_for_tune = 1e-8
epsilon_in_mirror = 1e-8
eta_ = 1 / 100
c1 = 0.3  # \in (0, 1)
beta1_design, beta2_design = 'beta1_1', 'beta2_1'
# beta1_design, beta2_design = 'beta1_2', 'beta2_2'
T = 100100
algorithm_nums = 3


# 参数设定
N = 32
noise_std = 0.05 # 噪声的标准差
spa_theta = 1
p = N
R = 2

# 加载.mat文件
fan_file = f'../data/fan_N{N}s{spa_theta}p{p}R{R}.mat'
data = sio.loadmat(fan_file)
A = csr_matrix(data['A'])  # 将 A 转换为稀疏矩阵格式
X_train = A.toarray()
y_free = data['y_free'].flatten()
w_star = data['w_star'].flatten()

np.random.seed(10)
# 对标签添加噪声
noise = noise_std * np.random.randn(len(y_free))
y_train = y_free + noise

# diff_w_set, error_set, n_sparse_set, w_current_epsilon_AdMD, w_current_L2norm_AdMD = main_function(X_train, y_train, X_train, y_free, T, w_star, epsilon_in_mirror, epsilon_for_tune, eta_, c1, beta1_design, beta2_design, algorithm_nums)
# # ☀️save final
# Runing_result = {
#     'w_current_epsilon_AdMD': w_current_epsilon_AdMD,
#     'w_current_L2norm_AdMD': w_current_L2norm_AdMD}
#
# filename = f'../tomo_result/image_recover.npy'
# np.save(filename, Runing_result)
#
#






filename = f'../tomo_result/image_recover.npy'
AdMD_result = np.load(filename, allow_pickle=True).item()
w_current_epsilon_AdMD = AdMD_result['w_current_epsilon_AdMD']
w_current_L2norm_AdMD = AdMD_result['w_current_L2norm_AdMD']


w = np.reshape(w_current_epsilon_AdMD, (N, N))
plt.imshow(w, cmap='gray')
plt.colorbar()
plt.xlabel('$\\mathbf{w}$ recovered by AdMD$_{\\Psi^{(\\epsilon)}(\mathbf{w})}$',
              fontsize='15')
plt.savefig(f'../tomo_figures/weight_image_thm2_epsilon_100100.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()



w = np.reshape(w_current_L2norm_AdMD, (N, N))
plt.imshow(w, cmap='gray')
plt.colorbar()
plt.xlabel('$\\mathbf{w}$ recovered by AdMD$_{\\Psi^{(\ell^2)}(\mathbf{w})}$',
              fontsize='15')
plt.savefig(f'../tomo_figures/weight_image_thm2_l2norm_100100.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()








